# MakerMods Lab — Windows training update

Fixes local policy training on Windows so a SmolVLA run starts, trains on the
GPU, and reports its step progress.

- **Base commit:** `e3771494` (`main`, "Merge pull request #174 from makermods-robotics/staging")
- **File changed:** `makermodslab/jobs.py` (only file)
- **Verified:** 2026-11-13 on Windows 11, Intel i9-13980HX, NVIDIA GeForce RTX 4080 Laptop GPU (12 GB, driver 566.07), Python 3.12, lerobot pinned at `5ce2fe41a`

## Contents of this folder

| File | What it is |
|---|---|
| `README.md` | This document |
| `windows-training-fix.patch` | `git diff` of `makermodslab/jobs.py` against `e3771494` — every change below |
| `jobs.py` | The full patched `makermodslab/jobs.py`, for copying over directly |
| `lab_TDMPC.html` | Step-by-step lab: record a task and train a TD-MPC policy (open in a browser) |
| `lab_TDMPC_prepare.py` | The lab's conversion script: one camera, 84 × 84 square images, `next.reward` |

**Also required for any local training on Windows:** saving a checkpoint creates
a `checkpoints\last` symbolic link, which Windows only allows with Developer
Mode on (Settings → System → For developers) or from a terminal run as
Administrator. Without either, training crashes at the first checkpoint with
`OSError: [WinError 1314] A required privilege is not held by the client`.

## Symptoms

1. **Training could not start or stop correctly on Windows.** The local job
   runner launched the trainer through `/bin/sh` and used POSIX process-group
   signals, none of which exist on Windows.
2. **SmolVLA failed at "Creating policy"** with:

   ```
   huggingface_hub.errors.HFValidationError: Repo id must use alphanumeric chars, '-', '_' or '.'.
   ... 'lerobot\smolvla_base'.
   ```

3. **After that was fixed, the step counter stayed at 0.** The trainer was
   running on the CPU (`'device': 'cpu'` in the log) and had not finished a
   single step after 6 minutes.

## Fix 1 — run and stop the trainer without POSIX tools (`jobs.py`)

| Where | POSIX behaviour | Windows behaviour now |
|---|---|---|
| `_pid_alive` | `os.kill(pid, 0)` probe | `psutil.pid_exists(pid)`. On Windows `os.kill` with any normal signal *terminates* the process, so the probe would kill the trainer it checks. |
| `LocalJobRunner.start` | Wraps the trainer in `/bin/sh -c 'trap "" HUP; …'` that writes the exit-status file; `start_new_session=True` | Runs the trainer command directly with `CREATE_NEW_PROCESS_GROUP`. |
| `LocalJobRunner._pump_stdout` | The shell wrapper writes the status file | Writes the exit-status file itself (atomically, via `.tmp` + `os.replace`) when the run ends on its own. A deliberate stop writes none, matching the wrapper. |
| `LocalJobRunner.stop` / `TailingJobRunner.stop` | `os.killpg(..., SIGTERM)` | `taskkill /PID <pid> /T /F` through the new `_kill_process_tree_windows`, which also ends the DataLoader worker processes. This is always a hard kill; the job is still filed as `interrupted`. |

All changes are gated on `_IS_WINDOWS = os.name == "nt"`; macOS and Linux run
the original code paths unchanged.

## Fix 2 — `lerobot\smolvla_base` repo-id error (`jobs.py`)

**Cause (a lerobot bug that only shows up on Windows):** lerobot declares
`PreTrainedConfig.pretrained_path` as a `Path`. The trainer is launched with
`--policy.pretrained_path=lerobot/smolvla_base`; on Windows that becomes a
`WindowsPath`, and its `str()` is `lerobot\smolvla_base`, which
`hf_hub_download` rejects as an invalid repo id. On macOS/Linux the slash
survives, which is why the bug never appeared there.

It affects any **local** Windows run that starts from a bare Hub repo id,
including the default foundation base for SmolVLA (`lerobot/smolvla_base`).

**Fix:** a local Windows run now downloads such a repo before the trainer starts
and passes lerobot the absolute local folder, which survives the `Path`
conversion intact.

- New helper `_is_windows_bare_repo_id(pretrained_path)` — true on Windows for a
  value shaped `owner/name` that has no `@` ref, is not an absolute path and is
  not an existing local folder.
- `needs_local_materialization` also returns true for such a value, so the
  existing background "Preparing fine-tune: downloading base checkpoint…" step
  runs for it (progress bar and Stop both work).
- `localize_pretrained_path` turns it into a `<repo>@root` ref and downloads it
  with the existing `download_hub_checkpoint_ref`, which skips `checkpoints/**`
  and `training_state/**`.

What you see in the log after the fix:

```
Preparing fine-tune: downloading base checkpoint lerobot/smolvla_base from lerobot/smolvla_base…
...
'pretrained_path': 'C:\\Users\\<you>\\.cache\\huggingface\\hub\\models--lerobot--smolvla_base\\snapshots\\<sha>',
...
Loading weights from local directory
```

The downloaded files are cached in the Hugging Face hub cache, so later runs
skip the download. Cloud (HF Jobs) and LAN-node runs are unchanged: they still
pass the repo id, and the remote machine resolves it.

## Fix 3 — train on the GPU (environment, no code change)

The virtual environment had the CPU-only PyTorch build (`torch 2.11.0+cpu`), so
SmolVLA (450M parameters) trained on the CPU at minutes per step. Replace it
with the CUDA build that matches the installed versions:

```powershell
# Stop any training job and the makermodslab server first — they lock the torch DLLs.
uv pip install --python .venv\Scripts\python.exe torch==2.11.0 torchvision==0.26.0 `
  --index-url https://download.pytorch.org/whl/cu126 `
  --reinstall-package torch --reinstall-package torchvision

# Check it — should print True and the GPU name
.venv\Scripts\python.exe -c "import torch; print(torch.cuda.is_available(), torch.cuda.get_device_name(0))"
```

- `cu126` was chosen because NVIDIA driver 566.07 supports CUDA up to 12.7. With
  a driver of 570 or later you can use `cu128` in the URL instead.
- A later `uv sync` or reinstall of the project can bring the CPU build back. If
  a training log shows `'device': 'cpu'`, run the command again.

**Result:** SmolVLA on `nypweech/dataset4all` (15 episodes, 10,177 frames),
batch size 8, 10,000 steps: `'device': 'cuda'`, about **2.35 steps/s**
(roughly 1 h 10 min for the run), 3.6 GB of GPU memory in use, about 44%
GPU utilisation.

## Harmless warning — `libtorchcodec`

Every training log starts with a long `Could not load libtorchcodec` traceback
for FFmpeg versions 8 to 4. It is a warning, not an error: lerobot falls back
to the `pyav` video decoder (`Falling back to 'pyav' as a default decoder`) and
training is unaffected. To silence it, install the "full-shared" FFmpeg build
(it ships the DLLs) and put its `bin` folder on `PATH`.

## How to apply

From the repository root, on a clean checkout of `e3771494`:

```powershell
git apply updatewin\windows-training-fix.patch
```

Or copy the full file over:

```powershell
Copy-Item updatewin\jobs.py makermodslab\jobs.py
```

Then:

1. Install the CUDA PyTorch build (Fix 3).
2. **Restart `makermodslab`.** A server started without `--dev` does not reload
   changed Python files; a server still running old code fails with the same
   `lerobot\smolvla_base` error even though the file on disk is fixed.
3. Start the training from the UI with the policy device left on "auto".

## How to confirm it worked

In the job's training log:

- `Preparing fine-tune: downloading base checkpoint lerobot/smolvla_base…` (first run only)
- `'device': 'cuda'`
- `Loading weights from local directory`
- `Training: …| 35/10000 [00:43<1:10:46, 2.35step/s]` — the step counter in the UI moves within a minute or two
- A checkpoint appears every `save_freq` steps (1,000 by default, about every 7 minutes at this speed)

## Not yet done

- The automated test suite (`pytest`) was not run: pytest is not installed in
  `.venv` (`uv pip install -e ".[test]"` adds it).
- These changes are not committed and not upstreamed. The `lerobot\…`
  conversion is a lerobot bug and could also be reported to the lerobot fork,
  so a bare repo id works on Windows without a pre-download.
