# Copyright 2026 MakerMods. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Turn a MakerMods Lab recording into a dataset TD-MPC can train on.

lerobot's TD-MPC accepts at most ONE camera, only SQUARE images, and needs a
reward on every frame (``next.reward``). A Lab recording has none of the three:
it usually has two 640x480 cameras and no reward. This script reads the
recorded dataset and writes a NEW one (the source is never modified) with:

  * one camera (``--camera``), center-cropped to a square and resized to
    ``--size`` x ``--size`` (84 by default, the size TD-MPC was designed for);
  * ``observation.state`` and ``action`` copied unchanged;
  * ``next.reward`` added: 1.0 on the last ``--success-frames`` frames of every
    successful episode, 0.0 everywhere else. Episodes listed in
    ``--failed-episodes`` get 0.0 on every frame.

Usage (from the repository root, PowerShell):

    .venv\\Scripts\\python.exe updatewin\\lab_TDMPC_prepare.py `
        --src <hf_user>/tdmpc_pick_raw `
        --dst <hf_user>/tdmpc_pick_84 `
        --camera front --size 84 --success-frames 30

Add ``--failed-episodes 3 7`` for episodes that did not complete the task,
``--max-episodes 2`` for a quick trial, and ``--push`` to upload the result.
"""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--src", required=True, help="Recorded dataset repo id, e.g. me/tdmpc_pick_raw")
    p.add_argument("--dst", required=True, help="New dataset repo id, e.g. me/tdmpc_pick_84")
    p.add_argument("--camera", default="front", help="Camera to keep (name without 'observation.images.')")
    p.add_argument("--size", type=int, default=84, help="Square output size in pixels (default 84)")
    p.add_argument(
        "--success-frames",
        type=int,
        default=30,
        help="Frames at the end of a successful episode that get reward 1.0 (default 30 = 1 s at 30 fps)",
    )
    p.add_argument("--failed-episodes", type=int, nargs="*", default=[], help="Episode indices that failed")
    p.add_argument("--max-episodes", type=int, default=None, help="Only convert the first N episodes")
    p.add_argument("--src-root", default=None, help="Local folder of the source (default: lerobot cache)")
    p.add_argument("--dst-root", default=None, help="Output folder (default: lerobot cache / --dst)")
    p.add_argument("--overwrite", action="store_true", help="Delete an existing output folder first")
    p.add_argument("--push", action="store_true", help="Upload the new dataset to the Hugging Face Hub")
    p.add_argument("--num-workers", type=int, default=4, help="Video-decoding worker processes")
    return p.parse_args()


def square_resize(images: torch.Tensor, size: int) -> np.ndarray:
    """(B, C, H, W) float in [0, 1] -> (B, size, size, C) uint8, center-cropped."""
    _, _, h, w = images.shape
    side = min(h, w)
    top, left = (h - side) // 2, (w - side) // 2
    cropped = images[:, :, top : top + side, left : left + side]
    resized = F.interpolate(cropped, size=(size, size), mode="bilinear", antialias=True, align_corners=False)
    out = (resized.clamp(0, 1) * 255).round().to(torch.uint8)
    return out.permute(0, 2, 3, 1).cpu().numpy()


def main() -> int:
    args = parse_args()

    from lerobot.datasets.lerobot_dataset import LeRobotDataset
    from lerobot.utils.constants import HF_LEROBOT_HOME

    cam_key = f"observation.images.{args.camera}"
    src = LeRobotDataset(args.src, root=args.src_root)
    feats = src.meta.features

    cameras = [k for k in feats if k.startswith("observation.images.")]
    if cam_key not in feats:
        print(f"Camera '{args.camera}' is not in {args.src}. Cameras found: {cameras}", file=sys.stderr)
        return 2
    for required in ("observation.state", "action"):
        if required not in feats:
            print(f"{args.src} has no '{required}' feature, which TD-MPC needs.", file=sys.stderr)
            return 2

    # Episode lengths, from the frame table (no video decoding needed).
    ep_col = np.asarray(src.hf_dataset["episode_index"])
    episodes = sorted(int(e) for e in np.unique(ep_col))
    if args.max_episodes is not None:
        episodes = episodes[: args.max_episodes]
    ep_len = {e: int((ep_col == e).sum()) for e in episodes}
    failed = set(args.failed_episodes)
    unknown = failed - set(episodes)
    if unknown:
        print(f"--failed-episodes not in the converted range: {sorted(unknown)}", file=sys.stderr)
        return 2

    dst_root = Path(args.dst_root) if args.dst_root else HF_LEROBOT_HOME / args.dst
    if dst_root.exists():
        if not args.overwrite:
            print(f"{dst_root} already exists. Pick another --dst or pass --overwrite.", file=sys.stderr)
            return 2
        shutil.rmtree(dst_root)

    dst_features = {
        "observation.state": dict(feats["observation.state"]),
        "action": dict(feats["action"]),
        cam_key: {
            "dtype": "video",
            "shape": [args.size, args.size, 3],
            "names": ["height", "width", "channels"],
        },
        "next.reward": {"dtype": "float32", "shape": [1], "names": None},
    }
    dst = LeRobotDataset.create(
        repo_id=args.dst,
        fps=src.fps,
        features=dst_features,
        root=dst_root,
        robot_type=src.meta.robot_type,
        use_videos=True,
    )

    # Every frame of the converted episodes, in order.
    keep = np.flatnonzero(np.isin(ep_col, episodes))
    subset = torch.utils.data.Subset(src, keep.tolist())
    loader = torch.utils.data.DataLoader(
        subset, batch_size=32, shuffle=False, num_workers=args.num_workers
    )

    print(
        f"Converting {len(episodes)} episodes ({len(keep)} frames) of {args.src}: "
        f"camera '{args.camera}' -> {args.size}x{args.size}, reward on the last "
        f"{args.success_frames} frames of each successful episode."
    )
    current_ep: int | None = None
    total_reward_frames = 0
    for batch in loader:
        images = square_resize(batch[cam_key], args.size)
        for i in range(images.shape[0]):
            ep = int(batch["episode_index"][i])
            frame = int(batch["frame_index"][i])
            if current_ep is not None and ep != current_ep:
                dst.save_episode()
                print(f"  episode {current_ep} saved")
            current_ep = ep
            success = ep not in failed and frame >= ep_len[ep] - args.success_frames
            total_reward_frames += int(success)
            dst.add_frame(
                {
                    "observation.state": batch["observation.state"][i].numpy().astype(np.float32),
                    "action": batch["action"][i].numpy().astype(np.float32),
                    cam_key: images[i],
                    "next.reward": np.array([1.0 if success else 0.0], dtype=np.float32),
                    "task": batch["task"][i],
                }
            )
    if current_ep is not None:
        dst.save_episode()
        print(f"  episode {current_ep} saved")
    dst.finalize()

    print(
        f"\nDone: {args.dst} at {dst_root}\n"
        f"  episodes: {len(episodes)} ({len(failed)} marked failed)\n"
        f"  frames:   {len(keep)} ({total_reward_frames} with reward 1.0)"
    )
    if args.push:
        dst.push_to_hub()
        print(f"  uploaded to https://huggingface.co/datasets/{args.dst}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
