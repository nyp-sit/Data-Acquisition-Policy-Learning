r"""Lab 1 instructor tool: per-run breakdown of shoulder_lift swing logs (arm_forward_back_*.csv).

Prints reached range, max error, delay, error/load at four points of the swing, overshoot,
saturation counts and how much the other joints moved. Run from the working folder:
    & $py .\lab_1\instructor\analyze_logs.py .\lab_1\logs
"""
import csv, glob, statistics, sys, os

J = ["shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll", "gripper"]
for path in sorted(glob.glob(os.path.join(sys.argv[1] if len(sys.argv) > 1 else ".", "arm_forward_back_*.csv"))):
    r = list(csv.DictReader(open(path)))
    f = lambda k: [float(x[k]) for x in r]
    t, p, g, l, v, c = f("t"), f("pos_shoulder_lift"), f("target_shoulder_lift"), f("load_shoulder_lift"), f("vel_shoulder_lift"), f("current_shoulder_lift")
    n = len(r)
    T = 3.0
    amp = max(abs(x) for x in g)
    print("=====", os.path.basename(path), "n", n, "t_end %.2f" % t[-1], "rate %.1f" % (n / t[-1]), "target amp %.1f" % amp)
    e = [g[i] - p[i] for i in range(n)]
    print("  reach %.1f..%.1f  maxerr %.1f  load %.1f..%.1f  maxI %.0f  temps %s" % (
        min(p), max(p), max(map(abs, e)), min(l), max(l), max(c), [max(f("temp_" + j)) for j in J]))
    # per-cycle
    cyc = []
    for k in range(int(round(t[-1] / T))):
        idx = [i for i in range(n) if T * k <= t[i] < T * (k + 1)]
        if idx:
            cyc.append((min(p[i] for i in idx), max(p[i] for i in idx), max(abs(e[i]) for i in idx)))
    print("  cycles", " ".join("%.1f/%.1f/%.1f" % c_ for c_ in cyc))
    # lag
    best = min(range(0, 30), key=lambda lag: sum((g[i - lag] - p[i]) ** 2 for i in range(60, n)))
    print("  lag %d samples = %.0f ms" % (best, best / 30 * 1000))
    for ph, name in [(0, "0 rising"), (0.25, "+peak"), (0.5, "0 falling"), (0.75, "-peak")]:
        ids = [i for i in range(90, n) if min(abs((t[i] % T) / T - ph), abs((t[i] % T) / T - ph - 1)) < 0.012]
        if ids:
            print("   %-10s err %+.2f load %+.1f pos %+.1f vel %+.1f" % (name, statistics.mean(e[i] for i in ids), statistics.mean(l[i] for i in ids),
                                                              statistics.mean(p[i] for i in ids), statistics.mean(v[i] for i in ids)))
    # overshoot past target at turnarounds: pos beyond amp
    print("  overshoot +: %.2f  -: %.2f" % (max(p) - amp, -amp - min(p)))
    # sat estimate: fraction with |load| >= 0.95*limit for limits 100 and 40
    print("  |load|>=38: %.1f%%  >=95: %.1f%%" % (100 * sum(abs(x) >= 38 for x in l) / n, 100 * sum(abs(x) >= 95 for x in l) / n))
    # other joints change
    for j in ["shoulder_pan", "elbow_flex", "wrist_flex"]:
        q = f("pos_" + j)
        print("   %s %.1f..%.1f load max %.1f" % (j, min(q), max(q), max(map(abs, f("load_" + j)))))
    # jitter: velocity sign changes near +peak (oscillation)
    dv = sum(1 for i in range(1, n) if (v[i] > 0) != (v[i - 1] > 0) and abs(v[i]) > 5)
    print("  vel sign flips (|v|>5):", dv)
