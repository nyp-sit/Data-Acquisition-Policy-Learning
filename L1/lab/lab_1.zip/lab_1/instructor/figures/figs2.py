"""Explanatory diagrams for the Lab 1 instructor guide (control loop, error breakdown, parameter effects)."""
import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

LOGS = Path(sys.argv[1])
OUT = Path(sys.argv[2])
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
# categorical slots in fixed order; the run number picks the slot (color follows the run)
RUN_COL = {1: "#2a78d6", 2: "#eb6834", 3: "#1baf7a", 4: "#eda100", 5: "#e87ba4"}
BOX_FILL, BOX_EDGE, TAG_FILL = "#eaf3f7", "#7fa7ba", "#fffdf0"

plt.rcParams.update({
    "font.family": "Calibri", "font.size": 9, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
    "xtick.color": INK2, "ytick.color": INK2, "axes.facecolor": SURFACE, "figure.facecolor": SURFACE,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "axes.titlecolor": INK, "axes.titlesize": 10, "axes.titleweight": "bold",
    "axes.titlelocation": "left", "legend.frameon": False,
})

RUNS = [  # run, label, file
    (1, "P 16 (default)", "arm_forward_back_20261124_085906.csv"),
    (2, "P 8", "arm_forward_back_20261124_092302.csv"),
    (3, "P 32", "arm_forward_back_20261124_092615.csv"),
    (4, "P 32, D 8", "arm_forward_back_20261124_092912.csv"),
    (5, "P 32, D 8, limit 400", "arm_forward_back_20261124_093417.csv"),
]


def load(name):
    rows = list(csv.DictReader(open(LOGS / name)))
    col = lambda k: [float(r[k]) for r in rows]
    return col("t"), col("target_shoulder_lift"), col("pos_shoulder_lift"), col("load_shoulder_lift")


def metrics(name):
    t, g, p, l = load(name)
    n = len(t)
    e = [g[i] - p[i] for i in range(n)]
    lag = min(range(30), key=lambda k: sum((g[i - k] - p[i]) ** 2 for i in range(60, n)))
    ids = [i for i in range(90, n) if min(abs((t[i] % 3) / 3 - 0.75), 1) < 0.012]
    hold_err = abs(sum(e[i] for i in ids) / len(ids))
    hold_load = sum(l[i] for i in ids) / len(ids)
    return dict(maxerr=max(map(abs, e)), lag_ms=lag / 30 * 1000, short=20 + min(p), peak=max(l),
                hold_err=hold_err, hold_load=hold_load)


M = {run: metrics(fn) for run, _, fn in RUNS}


def mono(s):
    return s


# ======================================================================= A. control loop
fig, ax = plt.subplots(figsize=(7.0, 3.0))
ax.set_xlim(0, 100)
ax.set_ylim(0, 44)
ax.axis("off")


def block(x, y, w, h, title, sub=None):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2", fc=BOX_FILL, ec=BOX_EDGE, lw=1.0))
    ax.text(x + w / 2, y + h / 2 + (2.0 if sub else 0), title, ha="center", va="center", fontsize=8.5, fontweight="bold", color=INK)
    if sub:
        ax.text(x + w / 2, y + h / 2 - 2.6, sub, ha="center", va="center", fontsize=7.5, color=INK2)


def tag(x, y, text):
    ax.text(x, y, text, ha="center", va="center", fontsize=7.2, color=INK,
            bbox=dict(boxstyle="round,pad=0.3", fc=TAG_FILL, ec="#e3c766", lw=0.8))


def arrow(x1, y1, x2, y2, label=None, lx=None, ly=None, dashed=False, rad=0.0):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=9, color=INK2, lw=1.0,
                                 ls=(0, (3, 2)) if dashed else "-", connectionstyle=f"arc3,rad={rad}"))
    if label:
        ax.text(lx if lx is not None else (x1 + x2) / 2, ly if ly is not None else (y1 + y2) / 2 + 1.8, label,
                ha="center", va="bottom", fontsize=7.2, color=INK2)


Y, H = 22, 10
block(0.5, Y, 15, H, "Program", "arm_forward_back.py")
ax.add_patch(plt.Circle((24, Y + H / 2), 2.4, fc=SURFACE, ec=INK2, lw=1.0))
ax.text(24, Y + H / 2, "−", ha="center", va="center", fontsize=11, color=INK)
block(30, Y, 19, H, "Servo controller", "torque = P×error − D×speed")
block(55, Y, 14, H, "Torque limit", "cap → SAT")
block(75, Y, 24, H, "Motor + arm", "plus gravity and friction")
arrow(16.4, Y + H / 2, 21.5, Y + H / 2, "target", 18.9, Y + H / 2 + 0.8)
arrow(26.5, Y + H / 2, 29.6, Y + H / 2)
ax.text(25.2, Y - 2.6, "error = target − position", ha="left", va="center", fontsize=7.2, color=INK2)
arrow(49.6, Y + H / 2, 54.6, Y + H / 2)
arrow(69.6, Y + H / 2, 74.6, Y + H / 2, "torque", 72.1, Y + H / 2 + 0.8)
# gravity into the arm
arrow(87, 42.5, 87, Y + H + 0.6)
ax.text(88.2, 39.5, "gravity", fontsize=7.2, color=INK2, ha="left")
# feedback: position back to the summing junction (inside the servo)
ax.plot([99.4, 99.9, 99.9, 24, 24], [Y + H / 2, Y + H / 2, 13.5, 13.5, 13.5], color=INK2, lw=1.0)
arrow(24, 13.5, 24, Y + H / 2 - 2.5)
ax.text(62, 14.3, "position feedback inside the servo (fast, every internal cycle)", ha="center", va="bottom", fontsize=7.2, color=INK2)
# readback to the program, dashed: 30 Hz over USB
ax.plot([99.9, 99.9, 8], [13.5, 6.5, 6.5], color=INK2, lw=1.0, ls=(0, (3, 2)))
arrow(8, 6.5, 8, Y - 0.6, dashed=True)
ax.text(54, 7.2, "readback over USB at 30 Hz: position, speed, load, current, temperature (the CSV log)",
        ha="center", va="bottom", fontsize=7.2, color=INK2)
# parameter tags
tag(8, Y + H + 5.5, "30 Hz loop: ≥ 33 ms delay")
tag(39.5, Y + H + 5.5, "P = stiffness · D = damping")
tag(62, Y + H + 5.5, "Torque_Limit")
fig.savefig(OUT / "figA_control_loop.png", dpi=220, bbox_inches="tight")
plt.close(fig)

# ======================================================================= B. error breakdown
lag_part, grav_part = (7.96 + 2.69) / 2, (7.96 - 2.69) / 2   # measured errors at 3 and 1
fig, ax = plt.subplots(figsize=(6.6, 2.0))
LAG_C, GRAV_C = "#2a78d6", "#eb6834"
rows = [("③ Passing 0 going −\n(lifting the arm)", +1), ("① Passing 0 going +\n(gravity helps)", -1)]
for yi, (label, sign) in enumerate(rows):
    y = yi
    ax.barh(y, lag_part, height=0.5, color=LAG_C, edgecolor=SURFACE, linewidth=2)
    if sign > 0:
        ax.barh(y, grav_part, left=lag_part, height=0.5, color=GRAV_C, edgecolor=SURFACE, linewidth=2)
        total = lag_part + grav_part
    else:
        ax.barh(y, grav_part, left=lag_part - grav_part, height=0.5, color="none", edgecolor=GRAV_C, hatch="////", linewidth=1.2)
        total = lag_part - grav_part
    ax.plot([total, total], [y - 0.36, y + 0.36], color=INK, lw=2)
    ax.text(total + 0.15 if sign > 0 else lag_part + 0.15, y, f"= {total:.1f}° error" if sign > 0 else f"→ {total:.1f}° error",
            va="center", fontsize=8.5, color=INK, fontweight="bold")
ax.text(lag_part / 2, 0, "speed lag ≈ 5.3°", ha="center", va="center", fontsize=8, color="white", fontweight="bold")
ax.text(lag_part + grav_part / 2, 0, "+ gravity ≈ 2.6°", ha="center", va="center", fontsize=8, color=INK)
ax.text(lag_part / 2 - 1.3, 1, "speed lag ≈ 5.3°", ha="center", va="center", fontsize=8, color="white", fontweight="bold")
ax.text(lag_part - grav_part / 2, 1.43, "− gravity ≈ 2.6° (removed)", ha="center", va="center", fontsize=7.5, color=INK2)
ax.set_yticks([0, 1], [r[0] for r in rows])
ax.set_xlim(0, 11)
ax.set_ylim(-0.5, 1.65)
ax.set_xlabel("tracking error (deg)")
ax.grid(axis="y", visible=False)
ax.set_title("Same speed, opposite gravity: 8.0° error one way, 2.7° the other")
fig.savefig(OUT / "figB_error_breakdown.png", dpi=200, bbox_inches="tight")
plt.close(fig)

# ======================================================================= C. error = load / stiffness
fig, ax = plt.subplots(figsize=(6.6, 3.2))
xs = [M[r]["hold_load"] / {1: 16, 2: 8, 3: 32, 4: 32, 5: 32}[r] for r, _, _ in RUNS]
ys = [M[r]["hold_err"] for r, _, _ in RUNS]
k = sum(x * y for x, y in zip(xs, ys)) / sum(x * x for x in xs)  # least-squares slope through 0
ax.plot([0, 3.0], [0, 3.0 * k], color=INK2, lw=1.2, ls=(0, (4, 2)))
ax.text(1.5, 1.5 * k + 1.6, f"fitted line: error ≈ {k:.1f} × load ÷ P", fontsize=8.5, color=INK, ha="right")
offsets = {1: (12, -10), 2: (-10, -14)}
for (r, label, _), x, y in zip(RUNS, xs, ys):
    ax.plot(x, y, "o", ms=9, color=RUN_COL[r], mec=SURFACE, mew=2, zorder=4)
    if r in offsets:
        ax.annotate(f"{label}: {y:.1f}° at {M[r]['hold_load']:.0f} % load", (x, y), xytext=offsets[r], textcoords="offset points",
                    fontsize=8, color=INK, ha="right" if r == 2 else "left", va="center")
# the three P 32 runs sit on top of each other: one label for the cluster
ax.annotate("P 32 runs (D 32 · D 8 · D 8 + limit 400):\n" + " · ".join(f"{M[r]['hold_err']:.1f}°" for r in (3, 4, 5))
            + f" at {min(M[r]['hold_load'] for r in (3, 4, 5)):.0f}–{max(M[r]['hold_load'] for r in (3, 4, 5)):.0f} % load",
            (xs[3], ys[3]), xytext=(60, -16), textcoords="offset points", fontsize=8, color=INK, ha="left", va="center",
            arrowprops=dict(arrowstyle="-", color=INK2, lw=0.6, shrinkA=0, shrinkB=6))
ax.set_xlim(0, 3.1)
ax.set_ylim(0, 11)
ax.set_xlabel("holding load ÷ P   (% of max torque per unit of P)")
ax.set_ylabel("error holding at − end (deg)")
ax.set_title("A stiffness-only servo needs error to make torque: error ≈ load ÷ P")
fig.savefig(OUT / "figC_error_vs_stiffness.png", dpi=200, bbox_inches="tight")
plt.close(fig)

# ======================================================================= D. parameter effects summary
panels = [("Max error (deg)", "maxerr", "{:.1f}°", 19.5), ("Delay (ms)", "lag_ms", "{:.0f}", 260),
          ("Short of −20° (deg)", "short", "{:.1f}°", 9.5), ("Peak load (%)", "peak", "{:.1f}", 45)]
fig, axes = plt.subplots(1, 4, figsize=(7.0, 2.5), sharey=True, gridspec_kw={"wspace": 0.12})
order = [2, 1, 3, 4, 5]  # softest to stiffest, top to bottom
names = {r: lab for r, lab, _ in RUNS}
for ax, (title, key, fmt, xmax) in zip(axes, panels):
    for yi, r in enumerate(order):
        v = M[r][key]
        ax.barh(yi, v, height=0.62, color=RUN_COL[r], edgecolor=SURFACE, linewidth=2)
        ax.text(v + xmax * 0.03, yi, fmt.format(v), va="center", fontsize=7.5, color=INK)
    ax.set_xlim(0, xmax)
    ax.set_title(title, fontsize=8.5)
    ax.grid(axis="y", visible=False)
    ax.set_xticks([])
    ax.spines["bottom"].set_visible(False)
axes[0].set_yticks(range(len(order)), [names[r] for r in order], fontsize=8)
axes[0].invert_yaxis()
fig.suptitle("P changes error, delay and sag; D and the torque limit barely change anything at this speed",
             x=0.08, ha="left", fontsize=10, fontweight="bold", color=INK, y=1.04)
fig.savefig(OUT / "figD_parameter_effects.png", dpi=200, bbox_inches="tight")
plt.close(fig)

# ======================================================================= E. torque headroom
fig, ax = plt.subplots(figsize=(6.6, 2.9))
for r, lab, fn, ls in [(1, "P 16, limit 1000 (default)", RUNS[0][2], "-"), (5, "P 32, D 8, limit 400", RUNS[4][2], "-")]:
    t, g, p, l = load(fn)
    idx = [i for i, x in enumerate(t) if 9.0 <= x <= 12.0]
    xs_, ys_ = [t[i] - 9.0 for i in idx], [l[i] for i in idx]
    ax.plot(xs_, ys_, color=RUN_COL[r], lw=2, label=lab)
ax.axhline(95, color=INK, lw=1, ls=(0, (4, 2)))
ax.text(0.03, 92, "SAT with the default limit 1000: 95 %", fontsize=8, color=INK, va="top")
ax.axhline(38, color=INK, lw=1, ls=(0, (4, 2)))
ax.text(0.03, 41, "SAT with limit 400: 38 %", fontsize=8, color=INK, va="bottom")
pk = M[5]["peak"]
ax.axhspan(pk, 38, color="#e3c766", alpha=0.35, lw=0)
ax.annotate(f"headroom only {38 - pk:.1f} points", xy=(1.62, 37.2), xytext=(0.25, 58), fontsize=8, color=INK,
            arrowprops=dict(arrowstyle="-", color=INK2, lw=0.7))
ax.axhline(0, color=INK2, lw=0.6)
ax.set_xlim(0, 3)
ax.set_ylim(-15, 100)
ax.set_xlabel("time in one swing (s)")
ax.set_ylabel("load (% of max torque)")
ax.set_title("A lower torque limit moves the SAT line down to the load")
ax.legend(loc="upper right", bbox_to_anchor=(1.0, 0.86), fontsize=8)
fig.savefig(OUT / "figE_torque_headroom.png", dpi=200, bbox_inches="tight")
plt.close(fig)

for r, lab, _ in RUNS:
    print(r, lab, {k_: round(v, 2) for k_, v in M[r].items()})
print("slope k =", round(k, 2))
