"""Figures for the Lab 1 instructor guide, from the reference-arm logs."""
import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

LOGS = Path(sys.argv[1])
OUT = Path(sys.argv[2])
SURFACE, INK, INK2, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
BLUE, ORANGE, AQUA, TARGET = "#2a78d6", "#eb6834", "#1baf7a", "#8d8c86"

plt.rcParams.update({
    "font.family": "Calibri", "font.size": 9, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
    "xtick.color": INK2, "ytick.color": INK2, "axes.facecolor": SURFACE, "figure.facecolor": SURFACE,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.6, "axes.spines.top": False,
    "axes.spines.right": False, "axes.titlecolor": INK, "axes.titlesize": 10, "axes.titleweight": "bold",
    "axes.titlelocation": "left", "legend.frameon": False,
})


def load(name):
    rows = list(csv.DictReader(open(LOGS / name)))
    col = lambda k: [float(r[k]) for r in rows]
    return col("t"), col("target_shoulder_lift"), col("pos_shoulder_lift"), col("load_shoulder_lift")


# ---- Figure 1: reference run, 2 cycles (t = 6..12 s), position vs target and load
t, g, p, l = load("arm_forward_back_20261124_085906.csv")
idx = [i for i, x in enumerate(t) if 6.0 <= x <= 12.0]
tt = [t[i] - 6.0 for i in idx]
fig, (a1, a2) = plt.subplots(2, 1, figsize=(6.6, 4.3), sharex=True, gridspec_kw={"height_ratios": [3, 2], "hspace": 0.28})
a1.plot(tt, [g[i] for i in idx], color=TARGET, lw=2, ls=(0, (4, 2)), label="target")
a1.plot(tt, [p[i] for i in idx], color=BLUE, lw=2, label="position")
a1.axhline(-20, color=INK2, lw=0.6, ls=":")
a1.axhline(20, color=INK2, lw=0.6, ls=":")
a1.set_ylabel("shoulder_lift (deg)")
a1.set_title("Position trails the target and stops short of −20°")
a1.set_ylim(-25, 25)
a1.legend(loc="lower right", bbox_to_anchor=(1.0, 1.0), ncol=2, fontsize=8, borderaxespad=0.2)
# annotations at the falling zero crossing of the 2nd displayed cycle and at the -peak
k = min(idx, key=lambda i: abs(t[i] - (6.0 + 3 + 1.5)))
a1.annotate("8° behind while\nlifting against gravity", xy=(t[k] - 6.0, p[k]), xytext=(t[k] - 6.0 + 0.35, 13),
            fontsize=8, color=INK, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.7))
k2 = min(idx, key=lambda i: abs(t[i] - (6.0 + 2.25)))
a1.annotate("reaches −16.9°,\nnot −20°", xy=(t[k2] - 6.0, p[k2]), xytext=(t[k2] - 6.0 + 0.4, -23),
            fontsize=8, color=INK, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.7))
# numbered points 1-4 on the 2nd swing: passing 0 going +, + end, passing 0 going -, - end
for num, ph in zip("1234", (0.0, 0.25, 0.5, 0.75)):
    ki = min(idx, key=lambda i: abs(t[i] - (6.0 + 3 + 3 * ph)))
    for ax_, ys in ((a1, p), (a2, l)):
        ax_.plot(t[ki] - 6.0, ys[ki], "o", ms=11, mfc=SURFACE, mec=INK, mew=1.2, zorder=5)
        ax_.text(t[ki] - 6.0, ys[ki], num, ha="center", va="center", fontsize=7.5, fontweight="bold", color=INK, zorder=6)
a2.plot(tt, [l[i] for i in idx], color=BLUE, lw=2)
a2.axhline(0, color=INK2, lw=0.6)
a2.set_ylabel("load (% of max torque)")
a2.set_xlabel("time (s), two 3 s swings")
a2.set_title("Load peaks at ~34 %, far below saturation (95 %)")
a2.set_ylim(-15, 40)
fig.savefig(OUT / "fig1_reference_run.png", dpi=200, bbox_inches="tight")
plt.close(fig)

# ---- Figure 2: stiffness comparison over one cycle (t = 9..12 s)
runs = [("P = 8", "arm_forward_back_20261124_092302.csv", ORANGE),
        ("P = 16 (default)", "arm_forward_back_20261124_085906.csv", BLUE),
        ("P = 32", "arm_forward_back_20261124_092615.csv", AQUA)]
fig, ax = plt.subplots(figsize=(6.6, 3.4))
t, g, _, _ = load(runs[1][1])
idx = [i for i, x in enumerate(t) if 9.0 <= x <= 12.0]
ax.plot([t[i] - 9.0 for i in idx], [g[i] for i in idx], color=TARGET, lw=2, ls=(0, (4, 2)), label="target")
nudge = {"P = 8": 0.0, "P = 16 (default)": 1.1, "P = 32": -1.3}
for name, fn, c in runs:
    t, g, p, _ = load(fn)
    idx = [i for i, x in enumerate(t) if 9.0 <= x <= 12.0]
    xs, ys = [t[i] - 9.0 for i in idx], [p[i] for i in idx]
    ax.plot(xs, ys, color=c, lw=2, label=name)
    lo = min(ys)
    x_end = max(x for x, y in zip(xs, ys) if abs(y - lo) < 0.3)   # end of the flat bottom
    ax.hlines(lo, x_end + 0.02, 3.08, color=c, lw=0.9, ls=(0, (1, 1.5)))
    ax.text(3.1, lo + nudge[name], f"{name.split(' (')[0]}: lowest {lo:.1f}°".replace("-", "−"), color=INK, fontsize=8, va="center")
ax.set_xlim(0, 3.95)
ax.set_ylim(-24, 24)
ax.set_ylabel("shoulder_lift (deg)")
ax.set_xlabel("time in one swing (s)")
ax.set_title("Higher stiffness (P) = less lag and less sag at the − end")
ax.legend(loc="upper right", ncol=4, fontsize=8)
fig.savefig(OUT / "fig2_stiffness.png", dpi=200, bbox_inches="tight")
plt.close(fig)
print("ok")
