// Builds lab_1/instructor/lab1_instructor_guide.docx
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, Header, Footer,
  AlignmentType, WidthType, ShadingType, BorderStyle, LevelFormat, PageNumber, TabStopType,
  HeadingLevel, PageBreak, TableLayoutType,
} = require("docx");

const OUT = process.argv[2];
const FIG = process.argv[3];

const FONT = "Calibri", MONO = "Consolas";
const C = { h: "1F5F7A", h2: "123B4C", ink: "1F2328", muted: "5F6B73", rule: "B7C9D3", head: "DCE8EE",
  code: "EEF0F2", note: "FFFDF0", noteBorder: "E3C766", key: "EAF3F7", keyBorder: "7FA7BA" };
const PAGE_W = 11906 - 2 * 1134; // 9638 dxa content width

// ---------- inline markup: **bold**, `code`
function runs(text, base = {}) {
  const parts = String(text).split(/(\*\*[^*]+\*\*|`[^`]+`)/g).filter(Boolean);
  return parts.map((p) => {
    if (p.startsWith("**")) return new TextRun({ text: p.slice(2, -2), bold: true, ...base });
    if (p.startsWith("`")) return new TextRun({ text: p.slice(1, -1), font: MONO, size: 19,
      shading: { type: ShadingType.CLEAR, fill: C.code, color: "auto" }, ...base });
    return new TextRun({ text: p, ...base });
  });
}
const P = (text, opts = {}) => new Paragraph({ children: runs(text, opts.run), spacing: { after: 120, line: 276 }, ...opts.para });
const H1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun(t)] });
const H2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun(t)] });
const H3 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_3, children: [new TextRun(t)] });
const B = (t, level = 0) => new Paragraph({ numbering: { reference: "bullets", level }, children: runs(t), spacing: { after: 60, line: 264 } });
let numInst = 0;
const NUM = (items) => { numInst += 1; const ref = "num" + numInst;
  NUMBERING.push({ reference: ref, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 360, hanging: 360 } } } }] });
  return items.map((t) => new Paragraph({ numbering: { reference: ref, level: 0 }, children: runs(t), spacing: { after: 60, line: 264 } })); };
const NUMBERING = [{ reference: "bullets", levels: [
  { level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 360, hanging: 240 } } } },
  { level: 1, format: LevelFormat.BULLET, text: "–", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 240 } } } }] }];

const border = { style: BorderStyle.SINGLE, size: 4, color: C.rule };
const borders = { top: border, bottom: border, left: border, right: border };

function table(header, rows, widths, opts = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const cell = (t, i, isHead, fill) => new TableCell({
    width: { size: widths[i], type: WidthType.DXA }, borders,
    shading: { type: ShadingType.CLEAR, color: "auto", fill: isHead ? C.head : (fill || "FFFFFF") },
    margins: { top: 50, bottom: 50, left: 90, right: 90 },
    children: String(t).split("\n").map((line) => new Paragraph({ spacing: { before: 20, after: 20 },
      children: runs(line, { size: 18, bold: isHead || undefined }) })),
  });
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths: widths, layout: TableLayoutType.FIXED,
    rows: [
      new TableRow({ tableHeader: true, cantSplit: true, children: header.map((h, i) => cell(h, i, true)) }),
      ...rows.map((r, ri) => new TableRow({ cantSplit: true,
        children: r.map((t, i) => cell(t, i, false, opts.highlightRow === ri ? C.key : null)) })),
    ],
  });
}
const gap = () => new Paragraph({ spacing: { after: 80 }, children: [] });

function box(title, lines, kind = "note") {
  const fill = kind === "note" ? C.note : C.key;
  const col = kind === "note" ? C.noteBorder : C.keyBorder;
  const b = { style: BorderStyle.SINGLE, size: 6, color: col };
  return new Table({
    width: { size: PAGE_W, type: WidthType.DXA }, columnWidths: [PAGE_W], layout: TableLayoutType.FIXED,
    rows: [new TableRow({ cantSplit: true, children: [new TableCell({
      width: { size: PAGE_W, type: WidthType.DXA },
      borders: { top: b, bottom: b, right: b, left: { style: BorderStyle.SINGLE, size: 24, color: col } },
      shading: { type: ShadingType.CLEAR, color: "auto", fill },
      margins: { top: 100, bottom: 100, left: 160, right: 160 },
      children: [new Paragraph({ spacing: { after: 60 }, children: [new TextRun({ text: title, bold: true, color: kind === "note" ? "8A6100" : C.h })] }),
        ...lines.map((l) => (typeof l === "string" ? new Paragraph({ spacing: { after: 60, line: 264 }, children: runs(l) }) : l))],
    })] })],
  });
}

function pngSize(file) { const b = fs.readFileSync(file); return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) }; }
function figure(file, caption, widthPx = 600) {
  const { w, h } = pngSize(file);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 60 },
      children: [new ImageRun({ type: "png", data: fs.readFileSync(file), transformation: { width: widthPx, height: Math.round(widthPx * h / w) },
        altText: { title: caption, description: caption, name: path.basename(file) } })] }),
    new Paragraph({ spacing: { after: 200 }, children: runs(caption, { size: 18, color: C.muted, italics: true }) }),
  ];
}

// ======================================================================= content
const body = [];
const add = (...xs) => xs.flat().forEach((x) => body.push(x));

// ---- title block
add(
  new Paragraph({ spacing: { before: 0, after: 60 }, children: [new TextRun({ text: "INSTRUCTOR GUIDE · PRACTICAL LAB 1", bold: true, color: C.muted, size: 20, characterSpacing: 40 })] }),
  new Paragraph({ heading: HeadingLevel.TITLE, children: [new TextRun("Move the Real SO-101 Robot Arm")] }),
  new Paragraph({ spacing: { after: 240 }, children: [new TextRun({ text: "Expected results, analysis and teaching notes for the embodied AI class", color: C.muted, size: 26 })] }),
  box("Not for learners", [
    "This guide contains the expected results and model answers. It lives in `lab_1\\instructor\\`. **Remove the `instructor` folder** before you copy `lab_1` to the learners' PCs.",
  ]),
  gap(),
);

// ---- 1. About
add(H1("1. About this guide"));
add(P("This guide shows what learners should see at each step of Lab 1, explains why the real arm behaves that way, and links each observation to what the learners are meant to learn. The last part shows how these observations carry into later embodied AI work with the SO-101: imitation learning, sim-to-real and safe deployment of learned policies."));
add(P("**Reference data.** All numbers come from five runs of `arm_forward_back.py` on the reference SO-ARM101 follower arm (24 Nov 2026, LeRobot 0.6.2). Each run swung `shoulder_lift` ±20° ten times with a 3 s period, sampled at 30 Hz (900 samples per run). The logs are in `instructor\\reference_logs\\`."));
add(table(["Run", "Log file", "Gains on shoulder_lift during the run", "Purpose"], [
  ["1", "`..._085906.csv`", "P 16, D 32, torque limit 1000 (LeRobot default)", "Step 5 reference run"],
  ["2", "`..._092302.csv`", "**P 8**, D 32, 1000", "Step 7: softer shoulder"],
  ["3", "`..._092615.csv`", "**P 32**, D 32, 1000", "Step 7: stiffer shoulder"],
  ["4", "`..._092912.csv`", "P 32, **D 8**, 1000", "Step 7: less damping"],
  ["5", "`..._093417.csv`", "P 32, D 8, **torque limit 400**", "Step 7: lower torque limit"],
], [600, 1900, 4200, 2938]));
add(gap());
add(P("The logs don't record the gains. The settings above are inferred from the run order (the same order as the Step 7 table), from the behaviour in each log, and from how `--save` works: it merges new values into `gains.json`, so the settings stack. `gains.json` was back at the defaults after run 5.", { run: { color: C.muted, size: 20, italics: true } }));
add(box("How to use the numbers", [
  "Learners' numbers will differ from these: calibration, assembly, cable routing and individual servos all play a part. Mark the **pattern and the reasoning**, not the exact values. The \"guide range\" columns give values that are normal for a healthy arm.",
  "The gripper exercise has no reference log yet. Its values in Section 6 are **predictions**, marked as such. Run the reference solution once on your arm and replace them.",
], "key"));

// ---- 2. Learning outcomes
add(H1("2. Learning outcomes and where the evidence is"));
add(table(["Learning outcome", "Steps", "Evidence the learner should hand in", "Key observation in the reference data"], [
  ["Connect to and calibrate the arm with LeRobot", "1–3", "COM port, calibration ID, a snapshot table", "All joints read ≈ 0° in the calibration middle pose"],
  ["Command a joint along a timed trajectory and stop the arm safely", "5, 8", "Completed run, CSV log, plot", "30.0 samples/s achieved; all 10 swings repeat within 0.3°"],
  ["Read the servo feedback and decide if a joint is fine, slow, weak or at a limit", "5–6", "\"Record your results\" table with a justified verdict", "8.1° error at 34 % load → **slow**, not weak; lopsided range → gravity"],
  ["Relate the servo's P and D to the simulator's stiffness and damping", "7", "Step 7 comparison and Q4", "P 8 → 15.0° error; P 32 → 5.3°; D 8 has no visible effect at this speed"],
  ["Change a working program to make a new motion", "Exercise", "`gripper_open_close.py`, E6 table", "One-sided raised-cosine motion; no clipping at 2–62 %"],
], [2700, 800, 2900, 3238]));

// ---- 3. Steps 1-4
add(H1("3. Steps 1–4: setting up"));
add(table(["Step", "What learners should see", "Common problems and what to tell them"], [
  ["1 Port", "`so101_cli.py ports` lists one CH340/CH343 port, e.g. `COM5`.", "No port: USB cable or driver. `Access is denied`: another program (often the joint monitor) has the port open."],
  ["2 Calibrate", "Calibration file `<SO101_ID>.json` saved under `%USERPROFILE%\\.cache\\huggingface\\lerobot\\calibration\\robots\\so_follower\\`.", "Joints not moved through their **full** range: limits come out too narrow, and later runs warn that targets are clipped. Redo the calibration."],
  ["3 Check", "Six rows. Torque ON: target = position, error ≈ 0, small loads. Rest pose has `shoulder_lift` ≈ −96° and `elbow_flex` ≈ +95°.", "`Failed to sync read`: arm power off or a loose 3-pin cable."],
  ["4 + directions", "A filled-in direction table. All joints within a few degrees of 0 in the middle pose. Gripper usually 0 ≈ closed.", "Directions depend on calibration, so groups can differ. Check that each group's table agrees with their Step 5 plot."],
], [1300, 4100, 4238]));
add(gap());
add(P("**Cross-check for Step 4.** In Step 5 the arm's weight pulls `shoulder_lift` toward the + end of the swing (Section 4.3). With the torque off, a learner holding the arm in the middle pose should feel it fall the same way. If their + direction disagrees, check the calibration before going further."));

// ---- 4. Step 5-6
add(H1("4. Steps 5–6: the reference swing test"));
add(H2("4.1 What the program prints"));
add(P("At the end of the run the joint summary for the reference arm was:"));
add(table(["joint", "min pos", "max pos", "max |err|", "max |load| %", "sat %", "max °C"], [
  ["shoulder_pan", "+0.5", "+0.9", "0.9", "5.2", "0", "30"],
  ["**shoulder_lift** (swung)", "**−16.9**", "**+20.2**", "**8.1**", "**33.6**", "**0**", "**32**"],
  ["elbow_flex", "+1.4", "+2.9", "2.9", "14.8", "0", "30"],
  ["wrist_flex", "−0.4", "−0.3", "0.4", "3.2", "0", "31"],
  ["wrist_roll", "−0.1", "−0.1", "0.1", "0.0", "0", "30"],
  ["gripper", "+0.0", "+0.0", "0.0", "2.0", "0", "31"],
], [2638, 1100, 1100, 1100, 1400, 1000, 1300], { highlightRow: 1 }));
add(gap());
add(P("The per-swing lines were almost identical: reached −16.6 to −16.9° .. +20.2°, maximum error 8.0–8.1°, 0 % saturated. The program kept 30.0 samples/s, as asked."));
add(figure(path.join(FIG, "fig1_reference_run.png"), "Figure 1. Reference run (P 16, D 32), two of the ten swings. The dashed line is the target and the blue line the position. The lower panel is the shoulder_lift load. Points 1–4 mark the four moments analysed in Section 4.3 b."));

add(H2("4.2 The verdict"));
add(P("Using the lab's \"How to read your numbers\" table:"));
add(B("**Large error (8.1°, above the 3° warning) with low load (34 %, far below 95 %)** → the joint is **slow**. The motor has plenty of torque left; it simply isn't asked to use it until the error is large."));
add(B("**Lopsided reached range (−16.9 .. +20.2)** → **gravity** helps the joint one way and resists it the other way."));
add(B("**0 % saturated, nothing clipped** → not weak, not at a limit."));
add(P("**Expected verdict: slow, with a gravity-lopsided range. Not weak, not at a limit.** A learner who writes \"weak\" has missed that the load never got near saturation. This is the most common misreading."));

add(H2("4.3 Why the arm behaves this way"));
add(P("The analysis below explains every feature of Figure 1. It is worth walking through with the class, because the same three effects appear on every SO-101 joint. Start with Figure 2: it shows where each setting the learners change in Step 7 acts, so they can predict its effect before they run the experiment."));
add(figure(path.join(FIG, "figA_control_loop.png"), "Figure 2. What happens between the program's target and the arm's motion. The servo runs its own fast position loop. The program only sends targets and reads feedback 30 times a second. P, D and the torque limit all act inside the servo, and gravity acts on the arm.", 640));
add(table(["Setting (Step 7)", "Where it acts in Figure 2", "Effect to predict"], [
  ["P (stiffness)", "Turns error into torque", "Higher P: less error for the same torque, so less lag and less sag"],
  ["D (damping)", "Subtracts torque in proportion to speed", "Resists fast changes; little effect on a slow, smooth swing"],
  ["Torque limit", "Caps the torque before the motor", "No effect until the needed torque reaches the cap, then SAT and the joint falls behind"],
  ["30 Hz program loop", "Between the program and the servo", "At least one sample (33 ms) of delay that no gain can remove"],
  ["Gravity", "Acts on the arm, outside the servo", "Adds a load that depends on pose and direction, which the servo has to balance with error"],
], [2000, 3000, 4638]));
add(gap());
add(H3("a) Lag that grows with speed"));
add(P("Shifting the target in time until it best matches the position gives a delay of **4 samples ≈ 133 ms**. The target moves fastest when it crosses 0, at 2π × 20° / 3 s ≈ **42°/s**. At that speed, 133 ms of delay is 42 × 0.133 ≈ **5.6°** of error. So most of the 8° comes from lag alone."));
add(H3("b) Gravity adds error one way and removes it the other way"));
add(P("The numbers 1–4 refer to the marked points in Figure 1."));
add(table(["Point in the swing", "Error (target − pos)", "Load", "What is happening"], [
  ["① Passing 0 going +", "+2.7°", "−7 %", "Gravity helps; the motor barely works"],
  ["② At the + end", "−0.2°", "+2 %", "Arm resting where gravity puts it"],
  ["③ Passing 0 going −", "**−8.0°**", "**+32 %**", "Lifting the arm against gravity at full speed"],
  ["④ At the − end", "−3.7°", "+17 %", "Holding the arm up against gravity"],
], [2500, 1900, 1300, 3938]));
add(gap());
add(P("Points ① and ③ have the same speed, so averaging them separates the two effects. **Speed lag ≈ (8.0 + 2.7) / 2 ≈ 5.3°**, the same in both directions. **Gravity ≈ (8.0 − 2.7) / 2 ≈ 2.6°**, added when moving toward − and taken away when moving toward +. Figure 3 shows the sum. The load tells the same story: about 5 times more effort is needed toward − than toward +."));
add(figure(path.join(FIG, "figB_error_breakdown.png"), "Figure 3. The same speed lag at points ① and ③, with gravity added on the way up and taken away on the way down."));
add(H3("c) A stiffness-only controller needs an error to make torque"));
add(P("LeRobot sets the servo's P = 16, D = 32, I = 0. With no integral term, the motor torque is roughly proportional to the error. To hold the arm up at the − end, the servo needs about 17 % load, and it only produces that when it is about 3° away from its target. That is why the arm stops at −16.9° instead of −20°. The same mechanism explains the **flat tops and bottoms** in Figure 1: when the target turns around, the joint waits until the error is big enough to overcome gravity and friction, then follows. Section 5 tests this directly: across all five runs, the holding error follows **error ≈ 3.5 × load ÷ P** (Figure 6)."));
add(P("The elbow shows the same effect without moving: its target is 0°, but it sits at +1.4 to +2.9° while carrying the forearm (7–15 % load), and the sag changes slightly as the shoulder angle changes."));
add(H3("d) The rest of the arm"));
add(P("`shoulder_pan`, `wrist_flex`, `wrist_roll` and `gripper` changed by 0.4° or less, so the swing does not shake the arm. All servos stayed between 30 and 32 °C. The peak load of 33.6 % is about 0.64 N·m (100 % ≈ 1.9 N·m stall torque)."));

add(H2("4.4 Completed \"Record your results\" table"));
add(table(["Question", "Reference arm", "Guide range for learners", "Sim (from the lab sheet)"], [
  ["Commanded range", "−20 .. +20°", "−20 .. +20°", "−34 .. +34°"],
  ["Reached range", "−16.9 .. +20.2°", "Uphill end 1–5° short; downhill end within 0.5°", "−15 .. +28°"],
  ["Largest error", "8.1° (0.14 rad)", "about 5–11°", "33° (0.58 rad)"],
  ["Load saturated", "0 % of steps", "0 %. Any SAT: check the clamp, cables and torque limit", "97 % of steps"],
  ["Hottest servo", "32 °C (shoulder_lift)", "below 45 °C", "–"],
  ["Verdict", "Slow, gravity-lopsided. Not weak, not at a limit", "Same verdict", "Not weak; damping 65 too high"],
], [1900, 2300, 3000, 2438]));
add(gap());
add(box("Comparing with the sim fairly", [
  "The sim swing was larger and faster (±34° in 2 s, top speed ≈ 107°/s against 42°/s here), so the two columns are not like for like. The sim saturated because its damping of 65 resisted speed. The real servo, at much lower speed, did not. Ask learners to rerun the sim at ±20° and 3 s before they conclude that \"the real arm tracks better\".",
], "note"));

// ---- 5. Step 7
add(H1("5. Step 7: stiffness, damping and torque limit"));
add(H2("5.1 Results across the five runs"));
add(table(["Run and gains", "Reached range", "Max error", "Delay", "Error holding at − end", "Peak load", "SAT", "Temp °C"], [
  ["1 · P 16, D 32 (default)", "−16.9 .. +20.2", "8.1°", "133 ms", "3.7°", "33.6 %", "0 %", "32"],
  ["2 · P 8", "**−11.9** .. +20.2", "**15.0°**", "**233 ms**", "**9.6°**", "33.6 %", "0 %", "37"],
  ["3 · P 32", "−18.0 .. +20.2", "5.3°", "100 ms", "2.1°", "38.4 %", "0 %", "40"],
  ["4 · P 32, D 8", "−18.1 .. +20.1", "5.3°", "100 ms", "2.0°", "37.1 %", "0 %", "40"],
  ["5 · P 32, D 8, limit 400", "−18.3 .. +20.1", "5.2°", "100 ms", "1.9°", "36.5 %", "0 % (SAT at 38 %)", "40"],
], [2050, 1350, 950, 850, 1300, 950, 1188, 1000]));
add(gap());
add(...figure(path.join(FIG, "fig2_stiffness.png"), "Figure 4. One swing at three stiffness settings, with the target dashed. Higher P follows the target more closely and gets closer to −20°."));
add(...figure(path.join(FIG, "figD_parameter_effects.png"), "Figure 5. The four measures for every run, side by side. Each colour is one run, the same in Figures 4–7. Changing P moves the first three measures; changing D or the torque limit leaves them almost unchanged.", 640));

add(H2("5.2 What each experiment shows"));
add(P("**Softer shoulder (P 8).** The error nearly doubles (8.1 → 15.0°), the delay grows from 133 to 233 ms, and the − end falls 8° short instead of 3°. The peak load is unchanged at 33.6 %: the arm still needs the same torque to lift it, and with a softer spring the servo needs a bigger error to produce it. This is the clearest demonstration in the lab that **error ≈ load ÷ stiffness**, and that a soft joint is slow, not weak."));
add(P("Figure 6 shows this for all five runs. Each point is the error while holding the arm at the − end, plotted against the holding load divided by P. All five fall on one straight line: **error ≈ 3.5 × load ÷ P**. Learners can use the line to predict a setting they haven't tried. At P 24 and about 19 % load it predicts an error of about 3.5 × 19 ÷ 24 ≈ 2.8°."));
add(...figure(path.join(FIG, "figC_error_vs_stiffness.png"), "Figure 6. Holding error against load ÷ P for the five runs. A stiffness-only servo makes torque from error, so halving P doubles the error needed to hold the same load."));
add(P("**Stiffer shoulder (P 32).** The error drops to 5.3°, the delay to 100 ms, and the − end reaches −18.0°. Doubling P from 16 to 32 cut the error by about a third, not by half. Some of the delay doesn't come from stiffness: the program sends and reads at 30 Hz, so one sample (33 ms) of delay is built into the loop. The velocity data show no oscillation, but ask learners whether they heard buzzing. LeRobot lowered the factory P of 32 to 16 to avoid it."));
add(P("**Less damping (D 8).** No visible change from run 3: same error, same delay, and no overshoot past +20° (0.14°). This is a correct result, not a failed experiment. The swing is slow and smooth, and gravity plus friction already damp it, so damping has little to act on. Damping matters for fast moves and sudden stops. For an extension, try a quick step move such as `so101_cli.py joint shoulder_lift 20` straight after a move to −20."));
add(P("**Lower torque limit (400).** SAT now triggers at 38 % load. The peak was 36.5 %, so the joint stayed just inside the limit and tracked as before. The margin was only 1.5 percentage points, though: a faster swing, a larger amplitude or an object in the gripper would push it over. Figure 7 shows why the limit made no difference: lowering it moves the SAT line down, but the load curve stays where it was until it touches the line."));
add(...figure(path.join(FIG, "figE_torque_headroom.png"), "Figure 7. Load during one swing at the default limit and at limit 400. The limit only matters once the load reaches its SAT line. At 400 the peak came within 1.5 points of it."));
add(box("Notes for running Step 7", [
  "**The gains stack.** `--save` merges new values into `gains.json`, so the \"less damping\" run on the reference arm still had P 32, and the torque-limit run had P 32 and D 8. Either tell learners to put the default back between experiments, or accept stacked results and ask them to state which gains were active.",
  "**The torque-limit experiment may not show SAT.** The lab sheet says SAT appears and \"the joint can't follow\". On the reference arm it didn't, because the peak load was just below 38 %. To show saturation for sure, use `--torque_limit 300` (SAT at 28.5 %), or keep 400 and set `PERIOD_S = 2.0`.",
  "**Reset before sign-off.** Run `& $py .\\lab_1\\tool\\so101_cli.py gains` and check P 16, D 32, limit 1000, or delete `lab_1\\tool\\gains.json`. Saved gains carry over to the next group.",
], "note"));
add(gap());
add(P("**Heat.** The shoulder servo warmed from 32 to 40 °C over the five runs (about 15 minutes), and the peak current rose from 266 to 312 mA at P 32. This is far below the 55 °C stop, but it shows heat building up with use. That matters in long sessions such as data collection."));

// ---- 6. Exercise
add(H1("6. Exercise: gripper open and close (predicted results)"));
add(box("These are predictions", [
  "No gripper log was recorded on the reference arm. The values below come from the gripper's settings and from the shoulder results. To replace them, run `& $py .\\lab_1\\tool\\solutions\\gripper_open_close.py --yes` once, then plot it with `plot_joint_log.py`.",
], "note"));
add(gap());
add(table(["Step", "Expected result", "Why"], [
  ["E1", "Closed ≈ 0 %, open ≈ 100 % on most arms", "Calibration sets 0 and 100 at the two ends of the jaw's travel"],
  ["E3 check", "`py_compile` prints nothing; `code --diff` shows only the docstring and comments", "The five changes are mechanical"],
  ["E4", "Plan reads `gripper moves between +2.0 and +62.0 %` with **no clipping warning**; 5 cycles in about 15 s", "Raised cosine stays between 2 and 62 %, inside 0–100"],
  ["E6 reached", "About 2 .. 62 %, within 1–2 %", "The jaw is light and has almost no gravity load"],
  ["E6 error", "Small, a few %", "No gravity load; peak target speed only A·π/T = 60 × π / 3 ≈ 63 %/s"],
  ["E6 load / SAT", "Low, under ~15 %; 0 % saturated", "SAT for the gripper is at about 48 % (95 % of its 50 % limit)"],
  ["E6 verdict", "**Fine** (perhaps slightly slow)", "Compare with the sim gripper, which was slow (0.33 s delay)"],
], [1300, 4300, 4038]));
add(gap());
add(P("**Experiment A (period 1 s).** The target is 3× faster (peak ≈ 188 %/s). Expect the error column to grow most, the jaw to open less than 62 % and possibly not close fully to 2 %, and the velocity to flatten at the servo's speed limit. The load rises but stays below SAT. The verdict becomes **slow**."));
add(P("**Experiment B (amplitude 150).** The program warns before starting. The target exceeds 100 % whenever 0.5 × (1 − cos) > 0.65, which is about **40 % of the steps**, so expect \"clipped ≈ 40 % of steps\". The jaw stops at the end of its calibrated range instead of pressing into the stop. With a sponge in the jaw and amplitude 60, the load should go to **SAT near 48 %** while the jaw is blocked, and the temperature climbs. Keep this short."));
add(P("**Experiment C (does the gripper disturb the arm?).** Expect a small ripple in the `wrist_flex` load in time with the gripper (a few %) and no visible change in the other joints."));

// ---- 7. Data quality
add(H1("7. Data-quality notes worth discussing"));
add(B("**A false temperature spike.** In run 2 the gripper temperature read 47 °C for one sample, between readings of 32 °C. A servo can't heat up by 15 °C in one second, so this is a read glitch on the serial bus. Use it to show learners how to sanity-check a sensor: is the change physically possible? The program's 55 °C stop would still trigger on a glitch that large. That is a deliberately cautious choice."));
add(B("**The starting state changes between runs.** The gripper read 100 % in run 2 and 0 % in the others, because the jaw was left open between runs (`START_POSE` leaves the gripper where it is). This is not an error, but it shows why the initial state belongs in every log."));
add(B("**Repeatability.** Over the ten swings, the reached range varied by less than 0.3° and the error by 0.1°. The arm's errors are **systematic**, not random. Systematic errors can be learned or compensated for; random ones can't."));
add(B("**Timing.** Every run kept exactly 30.0 samples/s. A learner reporting fewer (e.g. 18 samples/s) has a slow USB latency setting; see the lab's Troubleshooting table."));

// ---- 8. Model answers
add(H1("8. Model answers to the post-lab questions"));
add(P("**Q1. Target and position; large error with low load.**", { para: { keepNext: true } }));
add(P("The target (`Goal_Position`) is where the program tells the servo to go. The position (`Present_Position`) is where the joint actually is. The error is target − position. A large error with a low load means the servo isn't pushing hard, even though it could: its stiffness is low or the motion is too fast for it. The joint is **slow**, not weak. Reference arm: 8.1° error at only 34 % load."));
add(P("**Q2. Why a sine wave suits shoulder_lift but not the gripper.**", { para: { keepNext: true } }));
add(P("A sine wave around the centre goes equally far both ways (0 → +A → 0 → −A → 0). That suits the shoulder, which starts in the middle of its range. The gripper starts closed, at one end of its range, so the −A half would drive the jaw into its closed stop (or be clipped). The gripper needs a one-sided wave, `closed + A × 0.5 × (1 − cos(2πt/T))`, which goes closed → open → closed and starts and ends at zero speed. Sketch: the sine crosses the centre line twice per period; the raised cosine stays above \"closed\" and touches it at t = 0 and t = T."));
add(P("**Q3. Was the reached range symmetric?**", { para: { keepNext: true } }));
add(P("No: −16.9 .. +20.2° for a ±20° command. At this pose gravity pulls `shoulder_lift` toward +. Moving toward − lifts the arm, which needs about 32 % load against −7 % the other way. The P-only servo has to be about 3° away from its target to produce the 17 % holding torque at the − end, so it stops short. Toward +, gravity helps, so the joint reaches (and slightly passes) +20°."));
add(P("**Q4. What changed when P was lowered and raised?**", { para: { keepNext: true } }));
add(P("P 8: error 15.0°, − end only −11.9°, delay 233 ms. P 32: error 5.3°, − end −18.0°, delay 100 ms. The peak load hardly changed, because the arm needs the same torque either way; P only sets how much error it takes to produce it. P is the servo's **stiffness** and D its **damping**, like the sim's drive. The units differ, so match behaviour (delay, sag, saturation), not the numbers. In the sim, damping of 65 dominated and caused saturation. On the real arm, reducing D to 8 made no visible difference at this slow speed."));
add(P("**Q5. What could happen without clipping?**", { para: { keepNext: true } }));
add(P("A target beyond the calibrated range would drive the joint into its mechanical end stop, into another link or into the table. The servo would sit at its torque limit, draw high current and heat up until overload protection (`Overload_Torque`) cuts the torque. Gears or brackets could be damaged, and the arm could hit something or someone. The simulator just pressed the joint against its limit with the drive saturated, and nothing broke. Strong answers also note that clipping only knows each joint's range, not where the table or obstacles are."));

// ---- 9. Embodied AI
add(H1("9. Why this matters for embodied AI with the SO-101"));
add(P("In later labs the arm won't be driven by a hand-written sine wave but by a **learned policy**: for example an ACT, Diffusion Policy or SmolVLA model trained with LeRobot on teleoperated demonstrations. The policy does exactly what the learners' program did in this lab. About 30 times a second, it reads the joint state and sends new joint targets (`Goal_Position`). Everything learners measured here sits between the policy's output and the arm's actual motion. In Figure 2, the policy simply takes the place of the \"Program\" box, and every other box stays the same. Make this connection explicit at the end of the lab."));
add(table(["What learners observed", "What it means for embodied AI", "Habit to carry forward"], [
  ["Position trails the target by 100–233 ms (3–7 samples)", "In a LeRobot dataset, the `action` (the leader arm's position) runs ahead of `observation.state` by several frames. The policy has to learn that offset. Predicting a chunk of future actions, as ACT does, helps hide the delay.", "Expect action ≠ next state. Check the lag in recorded datasets before blaming the model."],
  ["The same commands produced up to 10° different motion at P 8 and P 32", "Gains are part of the robot's dynamics. Training with one set of gains and deploying with another causes a **distribution shift** that looks like a bad policy.", "Fix the gains for a project. Record `gains.json` and the calibration ID with every dataset. Reset gains after experiments."],
  ["Error depends on pose: 3° short against gravity, none with it", "The robot's accuracy varies across the workspace. Policies need demonstrations covering the poses they will use, and precise tasks are hardest where gravity load is high.", "Collect data across the whole workspace. Later: gravity feedforward or higher P only where needed."],
  ["Load and current showed which way was uphill; a blocked gripper saturates at ~48 %", "Load, current and temperature are free **proprioceptive sensors**. They can detect a successful grasp, a collision or a stalled joint, and can be added to a policy's observations.", "Log load and current, not just position. Use them for grasp checks and safety stops."],
  ["Reference logs give a delay of ~133 ms and a sag of ~3° at the default gains", "These are the numbers to match in Isaac Sim (**system identification**): tune the sim's stiffness and damping until its log looks the same. The real spread (P 8–32) suggests a range for **domain randomisation**.", "Validate the sim against a real log before training in it."],
  ["Clipping, torque limits and a temperature stop protected the arm", "A neural network can output any number. The same guard rails must stay active when a policy drives the arm, plus workspace limits, because clipping doesn't know where the table is.", "Never let a policy write to the servos without clipping, limits and a person at the power switch."],
  ["Peak load 34–38 % unloaded; the shoulder warmed 8 °C in 15 minutes", "Headroom shrinks with payload and speed, and heat builds up during long recording sessions. A hot servo behaves differently from a cold one.", "Plan rests during data collection. Watch temperature, and keep a safety margin below SAT."],
  ["Ten swings repeated within 0.3°", "The arm's errors are systematic and repeatable, so a learned controller can compensate for them. That is what makes low-cost arms like the SO-101 usable for imitation learning.", "Separate systematic errors (learnable) from noise (not learnable) when evaluating a policy."],
], [2600, 4000, 3038]));
add(gap());
add(P("**Closing message for learners:** a robot policy never moves the arm directly. It sends targets to small controllers that have their own stiffness, delay, torque limits and temperature. Knowing how to read those controllers, from the log rather than by guessing, is what lets you tell a bad model from a mis-set robot, and it is the first step in making sim-trained or demonstration-trained policies work on real hardware."));

// ---- 10. Marking
add(H1("10. Marking and sign-off guidance"));
add(table(["Item", "Accept when", "Watch for"], [
  ["Record-your-results table", "Values come from the learner's own summary and the verdict is justified with error **and** load", "Verdict \"weak\" with 0 % SAT; values copied from the lab sheet's example"],
  ["Step 7 comparison", "A prediction is written before each run and compared with the result; the active gains are stated", "Claiming D 8 caused overshoot with no evidence in the plot; gains not reset afterwards"],
  ["Gripper exercise", "Program runs with no clipping at 60 %; E6 table filled in; one experiment explained", "`START_POSE` gripper at the wrong end (jaw squeezes shut at the start)"],
  ["CSV logs and plots", "Two logs (swing and gripper), each with a plot", "Missing logs: the run was stopped before the end (Ctrl+C still saves a log)"],
  ["Sign-off item 7", "Arm in its rest pose, torque off with the arm supported, power off; `gains.json` at the defaults", "Arm left powered and holding; gains still changed for the next group"],
], [2300, 3900, 3438]));

// ---- Appendix
add(H1("Appendix: how the reference numbers were computed"));
add(B("**Reached range and maximum error:** minimum and maximum of `pos_shoulder_lift`, and the largest |`target` − `pos`|, from each CSV (the same as the program's summary)."));
add(B("**Delay:** the target was shifted by 0–30 samples, and the shift giving the smallest squared difference from the position was kept (first 2 s skipped)."));
add(B("**Phase table (4.3 b):** error and load were averaged at four points in the swing (0, ¼, ½ and ¾ of the period) over swings 2–10."));
add(B("**Error holding at the − end:** the average error at ¾ of the period, where the target is at −20° and momentarily still."));
add(P("The script that produced these numbers is `instructor\\analyze_logs.py`. Run it on a folder of logs to get the same breakdown for any group's runs: `& $py .\\lab_1\\instructor\\analyze_logs.py .\\lab_1\\logs`."));
add(P("The figures are made by `instructor\\figures\\figs.py` (Figures 1 and 4) and `figs2.py` (Figures 2, 3, 5, 6 and 7). Both take the log folder and an output folder, e.g. `& $py .\\lab_1\\instructor\\figures\\figs2.py .\\lab_1\\instructor\\reference_logs .\\lab_1\\instructor\\figures`. To make the same figures from a group's own logs, point them at a folder with that group's five runs and edit the file names in the `RUNS` list."));

// ======================================================================= document
const doc = new Document({
  creator: "Lab 1 instructor guide",
  title: "Lab 1 Instructor Guide: Move the Real SO-101 Robot Arm",
  description: "Expected results, analysis and teaching notes for Practical Lab 1",
  styles: {
    default: { document: { run: { font: FONT, size: 21, color: C.ink } } },
    paragraphStyles: [
      { id: "Title", name: "Title", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 44, bold: true, color: C.h2 }, paragraph: { spacing: { before: 0, after: 80 }, keepNext: true } },
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 30, bold: true, color: C.h }, paragraph: { spacing: { before: 360, after: 140 }, keepNext: true, outlineLevel: 0,
          border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: C.rule, space: 4 } } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 25, bold: true, color: C.h2 }, paragraph: { spacing: { before: 240, after: 100 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { font: FONT, size: 22, bold: true, color: C.h }, paragraph: { spacing: { before: 180, after: 60 }, keepNext: true, outlineLevel: 2 } },
    ],
  },
  numbering: { config: NUMBERING },
  sections: [{
    properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, right: 1134, bottom: 1134, left: 1134, header: 560, footer: 560 } } },
    headers: { default: new Header({ children: [new Paragraph({
      tabStops: [{ type: TabStopType.RIGHT, position: PAGE_W }],
      border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: C.rule, space: 4 } },
      children: [new TextRun({ text: "SO-101 Robot Arm Practical", size: 17, color: C.muted }),
        new TextRun({ text: "\tLab 1 Instructor Guide · not for learners", size: 17, color: C.muted })] })] }) },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "Page ", size: 17, color: C.muted }), new TextRun({ children: [PageNumber.CURRENT], size: 17, color: C.muted }),
        new TextRun({ text: " of ", size: 17, color: C.muted }), new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 17, color: C.muted })] })] }) },
    children: body,
  }],
});

Packer.toBuffer(doc).then((buf) => { fs.writeFileSync(OUT, buf); console.log("wrote", OUT); });
