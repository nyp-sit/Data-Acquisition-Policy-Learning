"""Swing the SO101 arm forward and backward N times in the live sim.

Run with:  python tools/sim_exec.py tools/arm_forward_back.py

The live process (zero_agent) keeps calling env.step(zeros) in its own loop.
This patches the env's step() so those zero actions are replaced by a sine
wave on shoulder_lift; after N cycles the original step() is restored.
Non-blocking: the existing loop drives the motion.

Joint monitoring (see docs/test-so101-arm-movement.md):
  - Terminal 1 gets a summary per cycle and a per-joint table at the end.
  - Any time:  python tools/sim_exec.py -c "print_joints()"  prints all joints now.
  - Every step of env 0 is logged and saved to logs/arm_forward_back_<time>.csv.
  - The "SO101 Joint Monitor" window (tools/joint_monitor.py) opens in Isaac Sim.
"""

import gc
import math
import os
import time

import torch
from isaaclab.envs import ManagerBasedRLEnv

# ---------------------------------------------------------------------------
# 1. Tunable parameters
# ---------------------------------------------------------------------------
# Number of full forward+back swings. More cycles = longer run; total run time
# is CYCLES * PERIOD_S seconds of *sim* time (wall time can be longer if the
# GUI runs slower than real time).
CYCLES = 10
# Seconds per forward+back cycle. Smaller = faster swing. The PD joint drive
# has to keep up, so very short periods (well under ~0.5 s) make the joint lag
# behind the target and the real swing comes out smaller than AMPLITUDE_RAD.
# The period is rounded to a whole number of env steps (1/30 s each for Reach).
PERIOD_S = 2.0
# Peak offset from the default pose, in radians (0.6 rad ~= 34 deg each way).
# Larger values swing further but can hit the joint limits (the target is then
# clamped by the joint) or push the arm into the table / itself.
AMPLITUDE_RAD = 0.6
# Which joint to swing. Must be a joint name of the robot articulation, e.g.
# "shoulder_pan" (left/right), "shoulder_lift" (forward/back), "elbow_flex",
# "wrist_flex", "wrist_roll", "gripper". Changing it moves a different joint
# with the same sine profile.
JOINT = "shoulder_lift"

# --- monitoring settings ---
# Open the live "SO101 Joint Monitor" window in Isaac Sim (tools/joint_monitor.py).
# False = terminal output and CSV only.
SHOW_MONITOR_WINDOW = True
# Save every step of env 0 (all joints) to a CSV in LOG_DIR when the run ends.
# Open it in Excel or pandas to plot position vs target per joint.
SAVE_CSV = True
WORKSPACE = "C:/SO101wClaudeIsaac"  # sim_exec sends the code as text, so __file__ is not available
LOG_DIR = f"{WORKSPACE}/logs"
# |torque| at or above this fraction of the effort limit counts as "saturated":
# the motor is at full strength and can't follow the target any harder.
SATURATION_FRACTION = 0.98

# ---------------------------------------------------------------------------
# 2. Find the running environment
# ---------------------------------------------------------------------------
# sim_exec.py runs this file inside the already-running Isaac Sim process, so
# we have no direct handle to the env. Scan all live Python objects for the
# ManagerBasedRLEnv instance created by the launcher. If no env is running
# (e.g. plain Isaac Sim launched without -Task) this raises StopIteration.
env = next(o for o in gc.get_objects() if isinstance(o, ManagerBasedRLEnv))

# Undo a previous run that is still in progress.
# The patch below sets env.step as an *instance* attribute, which shadows the
# class method. Deleting the instance attribute restores the original method,
# so running this script twice restarts the motion instead of stacking two
# patches on top of each other.
# Caveat: the previous run had already set episode_length_s to 1e6, so the
# orig_ep_len saved below will be 1e6 and the normal time-out is not restored
# when this run finishes. Restart the live sim to get the original value back.
if "step" in env.__dict__:
    del env.step

# ---------------------------------------------------------------------------
# 3. Capture the original state and precompute constants
# ---------------------------------------------------------------------------
# Keep the real step() so the patched version can forward to it and so it can
# be restored at the end.
orig_step = env.step
# Keep the episode length (12 s for Reach) so it can be restored afterwards.
orig_ep_len = env.cfg.episode_length_s
robot = env.scene["robot"]
joint_names = list(robot.joint_names)
# Column of the action tensor to drive. This uses the robot's joint order,
# which equals the action order because the SO101 arm_action is configured with
# joint_names=[".*"] (all joints, articulation order). If a task lists a subset
# or a different order of joints in arm_action, this index would point at the
# wrong joint.
joint_idx = joint_names.index(JOINT)
# JointPositionAction computes: target = default_joint_pos + scale * action
# (scale = 0.5 for SO101 Reach). We divide by scale later so AMPLITUDE_RAD is
# the real angle in radians, independent of the task's action scale.
scale = env.action_manager._terms["arm_action"].cfg.scale
# step_dt = sim.dt * decimation = 1/60 * 2 = 1/30 s per env.step() for Reach,
# so one 2 s cycle = 60 steps and 10 cycles = 600 env steps. round() rather
# than int() because 2.0 / (1/30) can come out as 59.999... in floating point.
steps_per_cycle = round(PERIOD_S / env.step_dt)
total_steps = CYCLES * steps_per_cycle
# Step counter held in a dict so the step() closure below can update it
# without a `global` / `nonlocal` declaration.
state = {"k": 0}

# ---------------------------------------------------------------------------
# 4. Joint monitoring (Python side)
# ---------------------------------------------------------------------------
# Max torque each motor may apply (N*m, from the actuator config). Used to
# detect saturation. Read once; it doesn't change while running.
effort_limits = robot.data.joint_effort_limits[0].tolist()


def read_joints(env_id=0):
    """Current state of every joint of one env, as four plain Python lists.

    joint_pos        measured angle (rad)
    joint_pos_target where the PD drive is told to go (rad) = default + scale * action
    joint_vel        measured speed (rad/s)
    applied_torque   motor torque after clipping to the effort limit (N*m)

    The data live on the GPU; stacking them first means one GPU->CPU copy
    instead of one per value, which keeps the per-step cost negligible.
    """
    d = robot.data
    return torch.stack(
        [d.joint_pos[env_id], d.joint_pos_target[env_id], d.joint_vel[env_id], d.applied_torque[env_id]]
    ).tolist()


def print_joints(env_id=0):
    """Print a table of all joints right now.

    Call it from Terminal 2 while the sim runs (output comes back to Terminal 2):
        python tools/sim_exec.py -c "print_joints()"
        python tools/sim_exec.py -c "print_joints(1)"     # second arm
    """
    pos, tgt, vel, trq = read_joints(env_id)
    lims = robot.data.soft_joint_pos_limits[env_id].tolist()
    print(f"env {env_id}  step {state['k']}/{total_steps}  " + ("(swinging)" if "step" in env.__dict__ else "(idle)"))
    print(f"{'joint':14s} {'pos rad':>8s} {'deg':>7s} {'target':>8s} {'error':>7s} {'vel':>7s} {'torque':>7s}  limits")
    for i, n in enumerate(joint_names):
        sat = "  SAT" if abs(trq[i]) >= SATURATION_FRACTION * effort_limits[i] else ""
        print(
            f"{n:14s} {pos[i]:+8.3f} {math.degrees(pos[i]):+7.1f} {tgt[i]:+8.3f} {tgt[i] - pos[i]:+7.3f}"
            f" {vel[i]:+7.2f} {trq[i]:+7.2f}  [{lims[i][0]:+.2f}, {lims[i][1]:+.2f}]{sat}"
        )


# Every step of env 0: [step, t, pos x6, target x6, vel x6, torque x6].
# Lives in the sim's Python namespace, so it can also be inspected live, e.g.
#   python tools/sim_exec.py -c "print(joint_log[-1])"
joint_log = []
csv_columns = ["step", "t"] + [f"{q}_{n}" for q in ("pos", "target", "vel", "torque") for n in joint_names]
# Running stats for the swung joint over the current cycle, printed and reset
# at the end of every cycle.
cycle_stats = {}


def reset_cycle_stats():
    cycle_stats.update(lo=math.inf, hi=-math.inf, max_err=0.0, sat=0, n=0)


def record(k):
    """Log the joint state after step k and update the per-cycle stats."""
    pos, tgt, vel, trq = read_joints(0)
    joint_log.append([k, round(k * env.step_dt, 4)] + pos + tgt + vel + trq)
    p = pos[joint_idx]
    cycle_stats["lo"] = min(cycle_stats["lo"], p)
    cycle_stats["hi"] = max(cycle_stats["hi"], p)
    cycle_stats["max_err"] = max(cycle_stats["max_err"], abs(tgt[joint_idx] - p))
    cycle_stats["sat"] += abs(trq[joint_idx]) >= SATURATION_FRACTION * effort_limits[joint_idx]
    cycle_stats["n"] += 1


def print_cycle_summary(cycle):
    # If "reached" is well short of the command, or the saturated share is
    # high, the joint can't follow this motion. Check the cause before changing
    # settings: a high drive damping makes the torque saturate whenever the joint
    # moves (shoulder_lift: damping 65 saturates above 1.9/65 = 0.03 rad/s), even
    # though the motor is strong enough. tools/sweep_joint.py measures which
    # AMPLITUDE_RAD / PERIOD_S combinations work, and can test other damping values.
    s = cycle_stats
    default = robot.data.default_joint_pos[0, joint_idx].item()
    print(
        f"[arm_forward_back] cycle {cycle}/{CYCLES}  {JOINT} reached {s['lo'] - default:+.2f} .. "
        f"{s['hi'] - default:+.2f} rad from default (commanded +/-{AMPLITUDE_RAD})  "
        f"max error {s['max_err']:.2f} rad  torque saturated {100 * s['sat'] / max(s['n'], 1):.0f}% of steps"
    )


def finish_log():
    """Print a per-joint summary of the whole run and save the CSV."""
    if not joint_log:
        return
    n = len(joint_names)
    cols = list(zip(*joint_log))  # column-wise view of the log
    print(f"[arm_forward_back] joint summary over {len(joint_log)} steps (env 0):")
    print(f"  {'joint':14s} {'min pos':>8s} {'max pos':>8s} {'max |err|':>9s} {'max |tau|':>9s} {'sat %':>6s}")
    for i, name in enumerate(joint_names):
        pos, tgt, trq = cols[2 + i], cols[2 + n + i], cols[2 + 3 * n + i]
        max_err = max(abs(a - b) for a, b in zip(tgt, pos))
        sat = sum(abs(t) >= SATURATION_FRACTION * effort_limits[i] for t in trq)
        print(
            f"  {name:14s} {min(pos):+8.3f} {max(pos):+8.3f} {max_err:9.3f} "
            f"{max(abs(t) for t in trq):9.2f} {100 * sat / len(trq):6.0f}"
        )
    if SAVE_CSV:
        os.makedirs(LOG_DIR, exist_ok=True)
        path = f"{LOG_DIR}/arm_forward_back_{time.strftime('%Y%m%d_%H%M%S')}.csv"
        with open(path, "w", encoding="utf-8") as f:
            f.write(",".join(csv_columns) + "\n")
            for row in joint_log:
                f.write(",".join(f"{v:.5g}" for v in row) + "\n")
        print(f"[arm_forward_back] joint log saved: {path}")


reset_cycle_stats()

# ---------------------------------------------------------------------------
# 5. Open the live joint monitor window (Isaac Sim side)
# ---------------------------------------------------------------------------
# Runs tools/joint_monitor.py in this same Python namespace (it closes any
# monitor window that is already open and opens a fresh one), then points its
# plot at the joint being swung. Done before the env is touched, so if the
# window fails to open the env is left exactly as it was.
if SHOW_MONITOR_WINDOW:
    monitor_path = f"{WORKSPACE}/tools/joint_monitor.py"
    with open(monitor_path, encoding="utf-8") as f:
        exec(compile(f.read(), monitor_path, "exec"), globals())
    globals()["_joint_monitor"].set_plot_joint(JOINT)  # defined by joint_monitor.py

# ---------------------------------------------------------------------------
# 6. Prepare the env for an uninterrupted motion
# ---------------------------------------------------------------------------
# Episodes normally time out after episode_length_s and the env resets the arm
# to a (randomised) start pose, which would cut a swing in half. Making the
# episode effectively infinite prevents that; max_episode_length is computed
# from cfg.episode_length_s on every check, so the change takes effect
# immediately. Other termination terms still apply.
env.cfg.episode_length_s = 1e6
# Start from a fresh episode so every run begins at a known pose and the
# episode step counter is zero.
env.reset()


# ---------------------------------------------------------------------------
# 7. Replacement step(): overwrite the agent's action with a sine wave
# ---------------------------------------------------------------------------
def step(actions):
    k = state["k"]

    # Finished: remove the patch, restore the original episode length, print the
    # joint summary / save the CSV, and forward this last call unchanged. From
    # the next call on, the loop calls the real step() directly and the zero
    # agent takes over again (zero action = default pose, so the arm returns to
    # its home position).
    if k >= total_steps:
        del env.step
        env.cfg.episode_length_s = orig_ep_len
        print(f"[arm_forward_back] done: {CYCLES} cycles")
        finish_log()
        return orig_step(actions)

    # Sim time since the motion started.
    t = k * env.step_dt
    # Copy so we don't modify the caller's tensor in place (the agent may reuse it).
    actions = actions.clone()
    # Same target for every env (all rows): a sine around the default pose.
    # sin starts at 0, so the arm starts at the default pose, swings to
    # +AMPLITUDE_RAD, back through default to -AMPLITUDE_RAD, and back again
    # once per PERIOD_S. Dividing by scale converts radians to action units.
    # All other joints keep whatever the agent sent (zeros = hold default pose).
    actions[:, joint_idx] = AMPLITUDE_RAD * math.sin(2 * math.pi * t / PERIOD_S) / scale

    # Run the real physics step with the modified actions, then log the joint
    # state it produced (position, target, velocity, torque of every joint).
    result = orig_step(actions)
    record(k)
    state["k"] = k + 1

    # End of a cycle: print how well the joint followed the command, then
    # start collecting stats for the next cycle.
    if state["k"] % steps_per_cycle == 0:
        print_cycle_summary(state["k"] // steps_per_cycle)
        reset_cycle_stats()
    return result


# ---------------------------------------------------------------------------
# 8. Install the patch and return immediately
# ---------------------------------------------------------------------------
# Assigning on the instance means the live loop's next env.step(...) call lands
# in our function. This script returns right away; the motion is driven by the
# existing loop, so the GUI never freezes.
env.step = step
print(f"Started: {CYCLES} x {PERIOD_S}s swings of {JOINT} (+/-{AMPLITUDE_RAD} rad), ~{CYCLES * PERIOD_S:.0f}s total")
