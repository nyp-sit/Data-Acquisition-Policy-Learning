"""Summarize TensorBoard scalars of an Isaac Lab training run as plain text.

Lets Claude read training progress (rewards, episode length, losses) without a
browser. Needs the `tensorboard` package -> run with env_isaaclab's python.

Usage:
    python tools/tb_summary.py                                  # latest run under the SO101 logs
    python tools/tb_summary.py C:/isaacsimlab/isaac_so_arm101/logs/rsl_rl/reach/2026-09-15_00-55-35
    python tools/tb_summary.py --filter reward --points 10
"""

import argparse
import glob
import os
import sys

from tensorboard.backend.event_processing.event_accumulator import EventAccumulator

DEFAULT_LOGS = r"C:\isaacsimlab\isaac_so_arm101\logs"


def latest_run(root: str) -> str:
    event_files = glob.glob(os.path.join(root, "**", "events.out.tfevents.*"), recursive=True)
    if not event_files:
        sys.exit(f"No TensorBoard event files under {root}")
    return os.path.dirname(max(event_files, key=os.path.getmtime))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("run", nargs="?", help="Run directory (default: most recent run under --logs)")
    parser.add_argument("--logs", default=DEFAULT_LOGS, help="Root searched when no run is given")
    parser.add_argument("--filter", default="", help="Only tags containing this substring (case-insensitive)")
    parser.add_argument("--points", type=int, default=6, help="Evenly spaced samples to print per tag")
    args = parser.parse_args()

    run = args.run or latest_run(args.logs)
    acc = EventAccumulator(run, size_guidance={"scalars": 0})
    acc.Reload()
    tags = [t for t in acc.Tags()["scalars"] if args.filter.lower() in t.lower()]
    print(f"run: {run}")
    if not tags:
        print("no matching scalar tags")
        return

    for tag in sorted(tags):
        events = acc.Scalars(tag)
        values = [e.value for e in events]
        n = len(events)
        idx = sorted({round(i * (n - 1) / max(args.points - 1, 1)) for i in range(args.points)}) if n > 1 else [0]
        samples = "  ".join(f"{events[i].step}:{events[i].value:.4g}" for i in idx)
        print(f"{tag}  [n={n} min={min(values):.4g} max={max(values):.4g} last={values[-1]:.4g}]")
        print(f"    step:value  {samples}")


if __name__ == "__main__":
    main()
