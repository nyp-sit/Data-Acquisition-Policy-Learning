"""Find swing settings a joint can actually follow: sweep amplitude x period in the live sim.

Run with:  python tools/sim_exec.py tools/sweep_joint.py

For every combination of CENTERS_RAD x AMPLITUDES_RAD x PERIODS_S it moves JOINT
(env 0..N, all arms) along   target = default + center + amplitude * sin(2*pi*t / period)
for CYCLES_PER_TRIAL cycles, and measures the LAST cycle (the first one is
allowed to settle):

  sat %    share of steps with |torque| >= 98% of the motor's maximum
  max err  largest |target - position| (rad)
  reached  lowest .. highest position, relative to default + center (rad)
  max vel  largest |velocity| (rad/s); the sim caps joints at 1.5 rad/s

An amplitude of 0 just holds the joint at the center, which shows whether the
motor can even carry the arm in that pose.

At the end, Terminal 1 shows one table per center (rows = amplitude,
columns = period) and the results are saved to logs/sweep_<joint>_<time>.csv.
They also stay in the sim as `sweep_results` (list of dicts).

Like arm_forward_back.py it patches env.step() and returns immediately, so the
GUI keeps running. Total sim time is printed when it starts.
"""

import gc
import math
import os
import time

import torch
from isaaclab.envs import ManagerBasedRLEnv

# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------
JOINT = "shoulder_lift"
# Offsets from the default pose to swing around (rad). Moving the center
# changes how much of the arm's weight the joint has to hold.
CENTERS_RAD = [0.0]
AMPLITUDES_RAD = [0.0, 0.1, 0.2, 0.3, 0.4, 0.6]
PERIODS_S = [2.0, 3.0, 4.0, 6.0]
CYCLES_PER_TRIAL = 2
# Time to move smoothly to a new center (or rest) before each trial.
SETTLE_S = 1.0
# What-if test of the joint's drive gains, applied only for this sweep and
# restored afterwards (None = keep the robot config's value). Nothing is saved
# to the robot config; edit isaac_so_arm101/robots/trs_so101/so_arm101.py for that.
STIFFNESS_OVERRIDE = None
DAMPING_OVERRIDE = None
# What counts as "good" in the printed tables.
GOOD_SAT_PCT = 5.0
GOOD_ERR_RAD = 0.10
SATURATION_FRACTION = 0.98
LOG_DIR = "C:/SO101wClaudeIsaac/logs"

# ---------------------------------------------------------------------------
# Setup (same approach as arm_forward_back.py)
# ---------------------------------------------------------------------------
env = next(o for o in gc.get_objects() if isinstance(o, ManagerBasedRLEnv))
if "step" in env.__dict__:  # stop any motion program that is still running
    del env.step
orig_step = env.step
orig_ep_len = env.cfg.episode_length_s if env.cfg.episode_length_s < 1e5 else 12.0
robot = env.scene["robot"]
joint_idx = list(robot.joint_names).index(JOINT)
scale = env.action_manager._terms["arm_action"].cfg.scale
effort_limit = robot.data.joint_effort_limits[0, joint_idx].item()
dt = env.step_dt
# The actuator group that drives JOINT, and the joint's column inside it.
def _indices(a):  # Isaac Lab stores "all joints" as slice(None)
    ji = a.joint_indices
    return list(range(robot.num_joints)) if isinstance(ji, slice) else [int(x) for x in ji]


actuator = next(a for a in robot.actuators.values() if joint_idx in _indices(a))
act_col = _indices(actuator).index(joint_idx)
orig_gains = (robot.data.joint_stiffness[0, joint_idx].item(), robot.data.joint_damping[0, joint_idx].item())


def set_gains(stiffness, damping):
    """Write drive gains to PhysX and to Isaac Lab's actuator (used for the torque estimate)."""
    robot.write_joint_stiffness_to_sim(stiffness, joint_ids=[joint_idx])
    robot.write_joint_damping_to_sim(damping, joint_ids=[joint_idx])
    actuator.stiffness[:, act_col] = stiffness
    actuator.damping[:, act_col] = damping


gains = (STIFFNESS_OVERRIDE if STIFFNESS_OVERRIDE is not None else orig_gains[0],
         DAMPING_OVERRIDE if DAMPING_OVERRIDE is not None else orig_gains[1])
settle_steps = round(SETTLE_S / dt)

# One trial per (center, amplitude, period). A hold (amplitude 0) needs only one period.
trials = []
for c in CENTERS_RAD:
    for a in AMPLITUDES_RAD:
        for p in PERIODS_S[:1] if a == 0 else PERIODS_S:
            steps_per_cycle = round(p / dt)
            trials.append(dict(center=c, amp=a, period=p, spc=steps_per_cycle,
                               motion_steps=CYCLES_PER_TRIAL * steps_per_cycle))
total_s = sum(SETTLE_S + t["motion_steps"] * dt for t in trials)
sweep_results = []
sweep = {"i": 0, "j": 0, "prev_center": 0.0, "stats": None}


def new_stats():
    return dict(lo=math.inf, hi=-math.inf, max_err=0.0, max_vel=0.0, sat=0, n=0)


def target_offset(tr, j):
    """Joint target relative to the default pose at step j of trial tr."""
    if j < settle_steps:  # smooth (cosine) move from the previous center
        f = 0.5 * (1 - math.cos(math.pi * j / settle_steps))
        return sweep["prev_center"] + (tr["center"] - sweep["prev_center"]) * f
    t = (j - settle_steps) * dt
    return tr["center"] + tr["amp"] * math.sin(2 * math.pi * t / tr["period"])


def finish():
    del env.step
    env.cfg.episode_length_s = orig_ep_len
    set_gains(*orig_gains)
    print(f"[sweep] done: {len(trials)} trials of {JOINT}, stiffness {gains[0]:g}, damping {gains[1]:g}"
          f" (restored to {orig_gains[0]:g} / {orig_gains[1]:g})")
    for c in CENTERS_RAD:
        rows = [r for r in sweep_results if r["center"] == c]
        hold = next((r for r in rows if r["amp"] == 0), None)
        print(f"\n[sweep] {JOINT}, center {c:+.2f} rad from default"
              + (f"  (hold only: sat {hold['sat_pct']:.0f}%, err {hold['max_err']:.3f}, sits at {hold['hi']:+.3f})" if hold else ""))
        print(f"  cell = sat% / max err (rad);  * = good (sat <= {GOOD_SAT_PCT:g}%, err <= {GOOD_ERR_RAD:g} rad)")
        print("  amp \\ period " + "".join(f"{p:>14.1f}s" for p in PERIODS_S))
        for a in [a for a in AMPLITUDES_RAD if a > 0]:
            cells = []
            for p in PERIODS_S:
                r = next(r for r in rows if r["amp"] == a and r["period"] == p)
                good = r["sat_pct"] <= GOOD_SAT_PCT and r["max_err"] <= GOOD_ERR_RAD
                cells.append(f"{r['sat_pct']:5.0f}% / {r['max_err']:.2f}{'*' if good else ' '}")
            print(f"  {a:>10.2f}   " + "".join(f"{c_:>15s}" for c_ in cells))
    os.makedirs(LOG_DIR, exist_ok=True)
    path = f"{LOG_DIR}/sweep_{JOINT}_{time.strftime('%Y%m%d_%H%M%S')}.csv"
    keys = ["center", "amp", "period", "sat_pct", "max_err", "lo", "hi", "max_vel", "peak_vel_needed"]
    with open(path, "w", encoding="utf-8") as f:
        f.write("stiffness,damping," + ",".join(keys) + "\n")
        for r in sweep_results:
            f.write(f"{gains[0]:g},{gains[1]:g}," + ",".join(f"{r[k]:.4g}" for k in keys) + "\n")
    print(f"\n[sweep] results saved: {path}")


def step(actions):
    # Any error in this tool must not reach the sim's own loop (it would close
    # Isaac Sim), so restore the original step() and report instead.
    try:
        return _step(actions)
    except Exception as ex:
        if "step" in env.__dict__:
            del env.step
        env.cfg.episode_length_s = orig_ep_len
        set_gains(*orig_gains)
        print(f"[sweep] stopped by an error: {ex!r}")
        return orig_step(actions)


def _step(actions):
    i, j = sweep["i"], sweep["j"]
    if i >= len(trials):
        finish()
        return orig_step(actions)
    tr = trials[i]
    actions = actions.clone()
    actions[:, joint_idx] = target_offset(tr, j) / scale
    result = orig_step(actions)

    # Measure only the last cycle of the motion.
    if j >= settle_steps + (CYCLES_PER_TRIAL - 1) * tr["spc"]:
        s = sweep["stats"]
        d = robot.data
        pos, tgt, vel, trq = torch.stack([d.joint_pos[0], d.joint_pos_target[0], d.joint_vel[0], d.applied_torque[0]])[
            :, joint_idx
        ].tolist()
        rel = pos - d.default_joint_pos[0, joint_idx].item() - tr["center"]
        s["lo"], s["hi"] = min(s["lo"], rel), max(s["hi"], rel)
        s["max_err"] = max(s["max_err"], abs(tgt - pos))
        s["max_vel"] = max(s["max_vel"], abs(vel))
        s["sat"] += abs(trq) >= SATURATION_FRACTION * effort_limit
        s["n"] += 1

    sweep["j"] = j + 1
    if sweep["j"] >= settle_steps + tr["motion_steps"]:  # trial finished
        s = sweep["stats"]
        sweep_results.append(dict(center=tr["center"], amp=tr["amp"], period=tr["period"],
                                  sat_pct=100 * s["sat"] / max(s["n"], 1), max_err=s["max_err"],
                                  lo=s["lo"], hi=s["hi"], max_vel=s["max_vel"],
                                  peak_vel_needed=2 * math.pi * tr["amp"] / tr["period"]))
        r = sweep_results[-1]
        print(f"[sweep] {i + 1}/{len(trials)} center {r['center']:+.2f} amp {r['amp']:.2f} period {r['period']:.1f}s: "
              f"sat {r['sat_pct']:.0f}%  max err {r['max_err']:.3f}  reached {r['lo']:+.2f}..{r['hi']:+.2f}  "
              f"max vel {r['max_vel']:.2f}")
        sweep.update(i=i + 1, j=0, prev_center=tr["center"], stats=new_stats())
    return result


sweep["stats"] = new_stats()
env.cfg.episode_length_s = 1e6
env.reset()
set_gains(*gains)
env.step = step
print(f"[sweep] started: {len(trials)} trials of {JOINT} (stiffness {gains[0]:g}, damping {gains[1]:g}), "
      f"about {total_s:.0f} s of sim time. Results print in Terminal 1.")
