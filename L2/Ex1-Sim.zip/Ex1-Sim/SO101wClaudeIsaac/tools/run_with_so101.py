"""Run an Isaac Lab script with the SO101 tasks registered.

Isaac Lab's generic scripts (record_demos.py, robomimic train.py / play.py, ...)
only import `isaaclab_tasks`, so they can't find `Isaac-SO-ARM101-*` tasks.
This wrapper imports `isaac_so_arm101.tasks` right after the script starts the
simulator (task configs can't be imported before that), then runs the script
unchanged with the remaining arguments. On Windows it also stands in for Isaac
Lab task modules that need the Linux-only `pink` library (see below).

Usage:
    python tools/run_with_so101.py <isaaclab_script.py> [script args ...]

Example:
    python tools/run_with_so101.py C:/isaacsimlab/IsaacLab/scripts/tools/record_demos.py \
        --task Isaac-SO-ARM101-Lift-Cube-IK-Rel-v0 --teleop_device keyboard
"""

import importlib
import os
import runpy
import sys
import types

from isaaclab.app import AppLauncher

if len(sys.argv) < 2:
    sys.exit(__doc__)

_orig_init = AppLauncher.__init__


def _init_and_register(self, *args, **kwargs):
    _orig_init(self, *args, **kwargs)
    import isaac_so_arm101.tasks  # noqa: F401  (registers the SO101 gym tasks)

    # robomimic train.py always imports Isaac Lab's humanoid pick-place tasks, which need the
    # Linux-only `pink` IK library. They aren't used here: replace them with empty modules if absent.
    for name in (
        "isaaclab_tasks.manager_based.manipulation.pick_place",
        "isaaclab_tasks.manager_based.locomanipulation.pick_place",
    ):
        try:
            importlib.import_module(name)
        except ImportError as e:
            print(f"[run_with_so101] skipping {name} ({e})")
            sys.modules[name] = types.ModuleType(name)


AppLauncher.__init__ = _init_and_register

script = os.path.abspath(sys.argv[1])
sys.argv = sys.argv[1:]
sys.path.insert(0, os.path.dirname(script))  # as if the script were run directly
runpy.run_path(script, run_name="__main__")
