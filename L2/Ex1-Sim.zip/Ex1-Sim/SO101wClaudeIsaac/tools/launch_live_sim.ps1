# Launch the Isaac Sim GUI with the code-execution socket (127.0.0.1:8226) enabled,
# so Claude can drive the live stage with tools/sim_exec.py.
#
#   .\tools\launch_live_sim.ps1                # full Isaac Sim GUI
#   .\tools\launch_live_sim.ps1 -Task Isaac-SO-ARM101-Reach-Play-v0
#                                              # SO101 Isaac Lab env (zero actions) with the socket on

param(
    [string]$Task = "",
    [int]$NumEnvs = 4
)

$env:OMNI_KIT_ACCEPT_EULA = "YES"
$IsaacEnv = "C:\isaacsimlab\env_isaaclab"
$Ext = "isaacsim.code_editor.vscode"

if ($Task) {
    Set-Location "C:\isaacsimlab\isaac_so_arm101"
    & "$IsaacEnv\Scripts\python.exe" -m isaac_so_arm101.scripts.zero_agent --task $Task --num_envs $NumEnvs --kit_args "--enable $Ext"
} else {
    & "$IsaacEnv\Scripts\isaacsim.exe" isaacsim.exp.full.kit --enable $Ext
}
