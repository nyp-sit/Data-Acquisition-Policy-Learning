"""Live joint monitor window for the SO101 arm inside Isaac Sim.

Run with:  python tools/sim_exec.py tools/joint_monitor.py
Close it with the window's X, or:  python tools/sim_exec.py -c "close_joint_monitor()"

Opens an "SO101 Joint Monitor" window that refreshes every frame. For each joint
of one environment it shows position, target, tracking error, velocity, motor
torque and where the joint sits inside its limits. A plot underneath draws the
selected joint's position against its target over the last ~10 s.

Why a custom window: Isaac Lab runs physics through Fabric, so the joint
attributes in Isaac Sim's Property panel (state:angular:physics:position,
drive target) are never updated and stay at 0. This window reads the same
tensors the RL env uses (robot.data.*), so what you see is what the policy sees.

Works with any SO101 task started by `tools/launch_live_sim.ps1 -Task ...`, with
or without tools/arm_forward_back.py running. Non-blocking: it hooks the app's
per-frame update event instead of looping, so the GUI stays responsive.
"""

import gc
import math

import carb.eventdispatcher
import omni.kit.app
import omni.ui as ui
import torch
from isaaclab.envs import ManagerBasedRLEnv

# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------
# Which environment (arm) to watch, 0 .. num_envs-1. All arms get the same
# command from arm_forward_back.py, so env 0 is representative.
ENV_ID = 0
# Joint shown in the plot when the window opens (can be changed in the window).
PLOT_JOINT = "shoulder_lift"
# Plot history in frames. One frame = one env step = 1/30 s for Reach, so 300
# frames ~= 10 s (5 swings at PERIOD_S = 2). More samples = longer history.
PLOT_SAMPLES = 300
# |torque| at or above this fraction of the joint's effort limit is shown red:
# the motor is saturated and can't push harder, so the joint lags its target.
SAT_FRACTION = 0.98
# |error| above this (rad) is shown yellow: the joint is noticeably off target.
ERR_WARN_RAD = 0.05

# omni.ui colors are 0xAABBGGRR (alpha, blue, green, red), not RGB.
WHITE = 0xFFDDDDDD
GREY = 0xFF888888
GREEN = 0xFF66CC66
YELLOW = 0xFF40D8FF
RED = 0xFF4848FF
BAR_BG = 0xFF333333


class JointMonitor:
    def __init__(self, env: ManagerBasedRLEnv, env_id: int, plot_joint: str):
        self.env = env
        self.env_id = env_id
        self.robot = env.scene["robot"]
        self.names = list(self.robot.joint_names)
        # Limits don't change while running, so read them once.
        # soft_joint_pos_limits = the joint range Isaac Lab uses (rad).
        self.limits = self.robot.data.soft_joint_pos_limits[env_id].tolist()
        # Max torque each motor may apply (N*m), from the actuator config.
        self.effort_limits = self.robot.data.joint_effort_limits[env_id].tolist()
        self.plot_idx = self.names.index(plot_joint)
        self.hist_pos: list[float] = []
        self.hist_tgt: list[float] = []
        self.rows: list[dict] = []
        self._build_ui()
        # Call _on_update once per rendered frame. Keeping the returned handle
        # keeps the subscription alive; setting it to None stops the updates.
        self._sub = carb.eventdispatcher.get_eventdispatcher().observe_event(
            event_name=omni.kit.app.GLOBAL_EVENT_UPDATE,
            on_event=self._on_update,
            observer_name="so101.joint_monitor",
        )

    # -- UI layout ----------------------------------------------------------
    def _build_ui(self):
        self.window = ui.Window("SO101 Joint Monitor", width=760, height=470)
        # Clicking the window's X hides it; stop updating when that happens.
        self.window.set_visibility_changed_fn(lambda visible: None if visible else self.close())
        col_w = [110, 130, 80, 80, 90, 110]
        with self.window.frame:
            with ui.VStack(spacing=4):
                self.header = ui.Label("", height=20, style={"color": WHITE})

                # Column headers.
                with ui.HStack(height=20):
                    for text, w in zip(
                        ["joint", "position rad (deg)", "target", "error", "vel rad/s", "torque N*m"], col_w
                    ):
                        ui.Label(text, width=w, style={"color": GREY})
                    ui.Label("position within limits", style={"color": GREY})

                # One row per joint.
                for i, name in enumerate(self.names):
                    lo, hi = self.limits[i]
                    with ui.HStack(height=20):
                        ui.Label(name, width=col_w[0], style={"color": WHITE})
                        row = {
                            "pos": ui.Label("", width=col_w[1]),
                            "tgt": ui.Label("", width=col_w[2]),
                            "err": ui.Label("", width=col_w[3]),
                            "vel": ui.Label("", width=col_w[4]),
                            "trq": ui.Label("", width=col_w[5]),
                        }
                        # Limit bar: left edge = lower limit, right edge = upper
                        # limit, fill = current position. A full or empty bar
                        # means the joint is pressed against a limit.
                        with ui.ZStack(height=14, tooltip=f"limits {lo:+.2f} .. {hi:+.2f} rad"):
                            ui.Rectangle(style={"background_color": BAR_BG})
                            with ui.HStack():
                                row["bar"] = ui.Rectangle(width=ui.Percent(50), style={"background_color": GREEN})
                                ui.Spacer()
                        self.rows.append(row)

                ui.Spacer(height=6)
                # Joint picker for the plot.
                with ui.HStack(height=22, spacing=8):
                    ui.Label("plot joint:", width=70, style={"color": GREY})
                    self.combo = combo = ui.ComboBox(self.plot_idx, *self.names, width=140)
                    combo.model.get_item_value_model().add_value_changed_fn(
                        lambda m: self._select_plot_joint(m.as_int)
                    )
                    ui.Label("green = position,  grey = target", style={"color": GREY})
                    self.plot_range = ui.Label("", width=200, style={"color": GREY})

                # Two plots stacked on top of each other with the same scale:
                # target (grey) underneath, measured position (green) on top.
                # The gap between the lines is the tracking error.
                with ui.ZStack(height=140):
                    self.plot_tgt = ui.Plot(ui.Type.LINE, -1.0, 1.0, 0.0, style={"color": GREY})
                    self.plot_pos = ui.Plot(
                        ui.Type.LINE, -1.0, 1.0, 0.0, style={"color": GREEN, "background_color": 0x00000000}
                    )
        self._select_plot_joint(self.plot_idx)

    def set_plot_joint(self, name: str):
        """Pick the plotted joint from code; same as choosing it in the drop-down."""
        self.combo.model.get_item_value_model().set_value(self.names.index(name))

    def _select_plot_joint(self, idx: int):
        # New joint: clear history and rescale the plot to that joint's limits.
        self.plot_idx = idx
        self.hist_pos.clear()
        self.hist_tgt.clear()
        lo, hi = self.limits[idx]
        for p in (self.plot_tgt, self.plot_pos):
            p.scale_min, p.scale_max = lo, hi
        self.plot_range.text = f"scale {lo:+.2f} .. {hi:+.2f} rad"

    # -- per-frame refresh --------------------------------------------------
    def _on_update(self, _event):
        try:
            self._refresh()
        except Exception as ex:  # e.g. env closed: stop instead of erroring every frame
            print(f"[joint_monitor] stopped: {ex!r}")
            self.close()

    def _refresh(self):
        d = self.robot.data
        e = self.env_id
        # Stack everything into one tensor so there is a single GPU->CPU copy per
        # frame (each .item()/.tolist() on a CUDA tensor forces a sync).
        #   joint_pos        measured joint angle (rad)
        #   joint_pos_target where the PD drive is told to go (rad); set by the action
        #   joint_vel        measured joint speed (rad/s)
        #   applied_torque   motor torque after clipping to the effort limit (N*m).
        #                    For implicit (PhysX) actuators this is Isaac Lab's
        #                    PD estimate, which matches what PhysX applies.
        pos, tgt, vel, trq = torch.stack(
            [d.joint_pos[e], d.joint_pos_target[e], d.joint_vel[e], d.applied_torque[e]]
        ).tolist()

        t = self.env.episode_length_buf[e].item() * self.env.step_dt
        driven = "arm_forward_back running" if "step" in self.env.__dict__ else "zero agent"
        self.header.text = f"env {e} of {self.env.num_envs}   episode time {t:6.2f} s   control: {driven}"

        for i, row in enumerate(self.rows):
            err = tgt[i] - pos[i]
            lo, hi = self.limits[i]
            sat = abs(trq[i]) >= SAT_FRACTION * self.effort_limits[i]
            row["pos"].text = f"{pos[i]:+.3f} ({math.degrees(pos[i]):+6.1f})"
            row["tgt"].text = f"{tgt[i]:+.3f}"
            row["err"].text = f"{err:+.3f}"
            row["err"].set_style({"color": YELLOW if abs(err) > ERR_WARN_RAD else WHITE})
            row["vel"].text = f"{vel[i]:+.2f}"
            row["trq"].text = f"{trq[i]:+.2f}" + ("  SAT" if sat else "")
            row["trq"].set_style({"color": RED if sat else WHITE})
            frac = min(max((pos[i] - lo) / (hi - lo), 0.0), 1.0)
            row["bar"].width = ui.Percent(frac * 100)
            near_limit = frac < 0.03 or frac > 0.97
            row["bar"].set_style({"background_color": RED if near_limit else GREEN})

        # Rolling history for the plot.
        self.hist_pos.append(pos[self.plot_idx])
        self.hist_tgt.append(tgt[self.plot_idx])
        if len(self.hist_pos) > PLOT_SAMPLES:
            del self.hist_pos[0], self.hist_tgt[0]
        self.plot_pos.set_data(*self.hist_pos)
        self.plot_tgt.set_data(*self.hist_tgt)

    def close(self):
        self._sub = None  # unsubscribe from frame updates
        # Clear self.window first: destroy() fires the visibility callback,
        # which calls close() again and must find nothing left to do.
        window, self.window = self.window, None
        if window:
            window.destroy()


def close_joint_monitor():
    global _joint_monitor
    if globals().get("_joint_monitor"):
        _joint_monitor.close()
        _joint_monitor = None


# Re-running the script replaces the window instead of opening a second one.
close_joint_monitor()

# Find the env the same way arm_forward_back.py does (sim_exec runs this file
# inside the live Isaac Sim process, so there is no direct handle to it).
_env = next(o for o in gc.get_objects() if isinstance(o, ManagerBasedRLEnv))
_joint_monitor = JointMonitor(_env, ENV_ID, PLOT_JOINT)
print(f"Joint monitor open: env {ENV_ID}, joints {', '.join(_joint_monitor.names)}")
