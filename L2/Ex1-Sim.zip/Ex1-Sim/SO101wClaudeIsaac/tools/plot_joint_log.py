"""Plot a joint log CSV written by tools/arm_forward_back.py (or a copy of it).

Run with the env python (any python with matplotlib works; the sim need not run):
    python tools/plot_joint_log.py                       # newest CSV in logs/
    python tools/plot_joint_log.py logs/<file>.csv
    python tools/plot_joint_log.py --out joints.png      # save instead of opening a window

One row of plots per joint: left = position (solid) vs target (dashed) in rad,
right = motor torque in N*m. A gap between position and target is tracking
error; torque flat at its maximum means the motor is saturated.
"""

import argparse
import csv
import glob
import os

import matplotlib.pyplot as plt

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "logs")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("csv", nargs="?", help="CSV file (default: newest *.csv in logs/)")
    parser.add_argument("--out", help="save the figure to this image file instead of showing it")
    args = parser.parse_args()

    path = args.csv or max(glob.glob(os.path.join(LOG_DIR, "*.csv")), key=os.path.getmtime)
    with open(path, encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    # Column names are pos_<joint>, target_<joint>, vel_<joint>, torque_<joint>.
    joints = [c[len("pos_"):] for c in rows[0] if c.startswith("pos_")]
    t = [float(r["t"]) for r in rows]

    fig, axes = plt.subplots(len(joints), 2, figsize=(12, 2 * len(joints)), sharex=True, squeeze=False)
    for i, j in enumerate(joints):
        ax_p, ax_t = axes[i]
        ax_p.plot(t, [float(r[f"pos_{j}"]) for r in rows], label="position")
        ax_p.plot(t, [float(r[f"target_{j}"]) for r in rows], "--", label="target")
        ax_p.set_ylabel(f"{j}\nrad")
        ax_t.plot(t, [float(r[f"torque_{j}"]) for r in rows], color="tab:red")
        ax_t.set_ylabel("N*m")
    axes[0][0].set_title("position vs target")
    axes[0][0].legend(loc="upper right")
    axes[0][1].set_title("motor torque")
    for ax in axes[-1]:
        ax.set_xlabel("time (s)")
    fig.suptitle(os.path.basename(path))
    fig.tight_layout()

    if args.out:
        fig.savefig(args.out, dpi=100)
        print(f"saved {args.out}")
    else:
        plt.show()


if __name__ == "__main__":
    main()
