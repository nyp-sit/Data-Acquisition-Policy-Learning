"""Run Python code inside a live Isaac Sim process (Claude's "live" interface).

Talks to the `isaacsim.code_editor.vscode` extension, which listens on
127.0.0.1:8226, executes received code in the Kit Python scope (state persists
between calls, top-level `await` works) and replies with JSON.

Stdlib only -- any Python can run this client.

Usage:
    python tools/sim_exec.py --ping
    python tools/sim_exec.py -c "import omni.usd; print(omni.usd.get_context().get_stage_url())"
    python tools/sim_exec.py path/to/snippet.py
    echo "print(1+1)" | python tools/sim_exec.py -
"""

import argparse
import json
import os
import socket
import sys

# The server executes each TCP chunk it receives separately, so large payloads
# could be split mid-statement. Above this size, ask the server to exec the file
# from disk instead (top-level `await` is then unavailable).
MAX_INLINE_BYTES = 32 * 1024


def send(code: str, host: str, port: int, timeout: float) -> dict:
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.sendall(code.encode("utf-8"))
        chunks = []
        while True:
            data = sock.recv(65536)
            if not data:
                break
            chunks.append(data)
    raw = b"".join(chunks).decode("utf-8", errors="replace")
    return json.loads(raw) if raw else {"status": "error", "output": "", "evalue": "empty reply"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("file", nargs="?", help="Python file to execute, or '-' for stdin")
    parser.add_argument("-c", "--code", help="Python code string to execute")
    parser.add_argument("--ping", action="store_true", help="Check that a live sim is reachable")
    parser.add_argument("--host", default=os.environ.get("ISAAC_EXEC_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("ISAAC_EXEC_PORT", "8226")))
    parser.add_argument("--timeout", type=float, default=120.0, help="Seconds to wait for the reply")
    args = parser.parse_args()

    if args.ping:
        code = "import omni.kit.app; print('Isaac Sim live, kit', omni.kit.app.get_app().get_kit_version())"
    elif args.code is not None:
        code = args.code
    elif args.file == "-":
        code = sys.stdin.read()
    elif args.file:
        path = os.path.abspath(args.file)
        with open(path, encoding="utf-8") as f:
            code = f.read()
        if len(code.encode("utf-8")) > MAX_INLINE_BYTES:
            code = f"exec(compile(open({path!r}, encoding='utf-8').read(), {path!r}, 'exec'), globals())"
    else:
        parser.error("give a file, '-', -c CODE, or --ping")

    try:
        reply = send(code, args.host, args.port, args.timeout)
    except (ConnectionRefusedError, socket.timeout, OSError) as e:
        print(
            f"Cannot reach Isaac Sim at {args.host}:{args.port} ({e}).\n"
            "Start it with tools/launch_live_sim.ps1 (or pass "
            '--kit_args "--enable isaacsim.code_editor.vscode" to an Isaac Lab script).',
            file=sys.stderr,
        )
        return 2

    if reply.get("output"):
        print(reply["output"])
    if reply.get("status") != "ok":
        print("".join(reply.get("traceback", [])) or f"{reply.get('ename')}: {reply.get('evalue')}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
