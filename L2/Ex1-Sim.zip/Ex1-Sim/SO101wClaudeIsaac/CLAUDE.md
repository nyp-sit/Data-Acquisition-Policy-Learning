# SO101 x Isaac Sim / Isaac Lab workspace

Claude drives NVIDIA Isaac Sim 5.1 + Isaac Lab 2.3 for SO-ARM101 simulation, RL and imitation learning.

## Machine
- Windows 11, RTX 5060 Laptop GPU (8 GB VRAM, Blackwell sm_120), driver 592.01
- 8 GB VRAM is the main constraint: keep `--num_envs` <= ~1024 for state-based RL, <= ~32 with cameras. Always train `--headless`.

## Paths
| What | Path |
|---|---|
| Python env (the ONLY one to use) | `C:\isaacsimlab\env_isaaclab\Scripts\python.exe` (py 3.11, torch 2.7.0+cu128) |
| Isaac Lab source (editable) | `C:\isaacsimlab\IsaacLab` |
| SO101 tasks package (editable) | `C:\isaacsimlab\isaac_so_arm101\src\isaac_so_arm101` |
| SO101 training logs/checkpoints | `C:\isaacsimlab\isaac_so_arm101\logs\rsl_rl\<experiment>\<timestamp>\` |
| This workspace's helper tools | `tools\` |

`C:\isaacsimlab\isaac_so_arm101\.venv` is empty/unused — do not use `uv run` there.
`OMNI_KIT_ACCEPT_EULA=YES` is set via `.claude/settings.json`.

## Registered SO101 tasks
`Isaac-SO-ARM101-Reach-v0`, `Isaac-SO-ARM101-Reach-Play-v0`, `Isaac-SO-ARM101-Lift-Cube-v0`, `Isaac-SO-ARM101-Lift-Cube-Play-v0` (plus SO-ARM100 variants). Note the `Isaac-` prefix; the upstream README omits it.

## Commands (run from `C:\isaacsimlab\isaac_so_arm101` so logs land in its `logs\`)
```powershell
$py = "C:\isaacsimlab\env_isaaclab\Scripts\python.exe"
& $py -m isaac_so_arm101.scripts.list_envs
& $py -m isaac_so_arm101.scripts.rsl_rl.train --task Isaac-SO-ARM101-Reach-v0 --headless --num_envs 512
& $py -m isaac_so_arm101.scripts.rsl_rl.play  --task Isaac-SO-ARM101-Reach-Play-v0 --num_envs 4      # GUI
& $py -m isaac_so_arm101.scripts.rsl_rl.play  --task Isaac-SO-ARM101-Reach-Play-v0 --headless --video --video_length 300
```
Isaac Lab's generic scripts (skrl, sb3, rl_games, robomimic, mimic, teleop, record_demos) live in `C:\isaacsimlab\IsaacLab\scripts\` and take the same `--task`.
They need `import isaac_so_arm101.tasks` (or `--task` registered elsewhere) to see SO101 tasks.

## How Claude works with the sim
1. **Batch / headless (default for RL & IL):** edit task configs or scripts, run them with the env python, read stdout + logs.
   - Training runs take minutes to hours: start them with `run_in_background` and check progress with
     `& $py tools\tb_summary.py` (latest run) or `--filter reward`.
   - First launch after an install compiles shaders and can sit silent for 5–10 min; that is not a hang.
2. **Live GUI:** user runs `tools\launch_live_sim.ps1` (plain Isaac Sim) or `tools\launch_live_sim.ps1 -Task <id>` (SO101 env).
   Claude then executes code in that process: `python tools\sim_exec.py --ping`, `-c "<code>"`, or `<file.py>`.
   State persists between calls; top-level `await` works (e.g. `await omni.kit.app.get_app().next_update_async()`).
   Never run blocking loops in the live process — it freezes the GUI.

## Conventions
- Before editing `isaac_so_arm101` or `IsaacLab`, check `git status` in that repo; both are git clones. Keep changes small and committed per experiment.
- New task variants: add a config class + `gym.register` in the task's `__init__.py`; never edit Isaac Lab core for task-specific changes.
- When reporting a training result, quote the run dir, iterations, and final `Train/mean_reward` / episode length from `tb_summary.py`.
- Python on Windows: use raw strings or forward slashes for paths in scripts.
