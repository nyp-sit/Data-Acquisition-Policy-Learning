"""Command-line control for the SO-101 follower arm.

Port and calibration id come from --port/--id, or the SO101_PORT / SO101_ID environment variables.

    python so101_cli.py ports                          # list serial ports
    python so101_cli.py calibrate                      # one-time LeRobot calibration
    python so101_cli.py read                           # print joint positions and limits
    python so101_cli.py move --shoulder_pan 20 --elbow_flex -15 --duration 2
    python so101_cli.py joint wrist_roll 45            # one joint, absolute
    python so101_cli.py joint wrist_roll -10 --relative
    python so101_cli.py gripper open | close | 40
    python so101_cli.py home                           # all body joints to 0 deg
    python so101_cli.py torque off                     # go limp (support the arm first!)
    python so101_cli.py pose save rest | go rest | list
    python so101_cli.py gains                          # show stiffness/damping per joint
    python so101_cli.py gains shoulder_lift --p 24 --d 40 --save
    python so101_cli.py shell                          # interactive prompt, one connection
"""

from __future__ import annotations

import argparse
import logging
import shlex
import sys

from so101_arm import DEFAULT_ID, DEFAULT_PORT, GAIN_REGISTERS, GRIPPER, JOINTS, SO101Arm, list_serial_ports


def print_positions(positions: dict[str, float], limits: dict[str, tuple[float, float]] | None = None) -> None:
    for name in JOINTS:
        unit = "%" if name == GRIPPER else "deg"
        line = f"  {name:<14} {positions[name]:8.2f} {unit}"
        if limits:
            lo, hi = limits[name]
            line += f"    [{lo:7.1f} .. {hi:6.1f}]"
        print(line)


def build_command_parser() -> argparse.ArgumentParser:
    """Parser for arm commands; shared by the one-shot CLI and the interactive shell."""
    parser = argparse.ArgumentParser(prog="so101", add_help=True)
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("read", help="print current joint positions")

    move = sub.add_parser("move", help="move one or more joints to absolute targets")
    for name in JOINTS:
        move.add_argument(f"--{name}", type=float, metavar="VAL")
    move.add_argument("--relative", action="store_true", help="treat values as offsets")
    move.add_argument("--duration", type=float, help="seconds (default: from arm speed)")

    joint = sub.add_parser("joint", help="move a single joint")
    joint.add_argument("name", choices=JOINTS)
    joint.add_argument("value", type=float)
    joint.add_argument("--relative", action="store_true")
    joint.add_argument("--duration", type=float)

    grip = sub.add_parser("gripper", help="open, close, or set gripper percent")
    grip.add_argument("value", help="'open', 'close' or 0..100")
    grip.add_argument("--duration", type=float)

    home = sub.add_parser("home", help="all body joints to 0 deg (calibration middle pose)")
    home.add_argument("--duration", type=float)

    torque = sub.add_parser("torque", help="enable or disable servo torque")
    torque.add_argument("state", choices=("on", "off"))

    pose = sub.add_parser("pose", help="save / go to / list named poses (tool/poses.json)")
    pose.add_argument("action", choices=("save", "go", "list"))
    pose.add_argument("name", nargs="?")
    pose.add_argument("--duration", type=float)

    gains = sub.add_parser("gains", help="show or set per-joint stiffness (p) / damping (d)")
    gains.add_argument("joint", nargs="?", choices=(*JOINTS, "all"), help="omit to show all joints")
    for key in GAIN_REGISTERS:
        gains.add_argument(f"--{key}", type=int, metavar="N")
    gains.add_argument("--save", action="store_true", help="store in tool/gains.json, re-applied on connect")

    speed = sub.add_parser("speed", help="set default speed in deg/s (shell only)")
    speed.add_argument("value", type=float)

    return parser


def run_command(arm: SO101Arm, args: argparse.Namespace) -> None:
    cmd = args.command
    if cmd == "read":
        print_positions(arm.get_positions(), arm.joint_limits)

    elif cmd == "move":
        targets = {name: getattr(args, name) for name in JOINTS if getattr(args, name) is not None}
        if not targets:
            print("Nothing to move: pass at least one --<joint> VALUE")
            return
        mover = arm.move_relative if args.relative else arm.move_to
        print_positions(mover(targets, args.duration))

    elif cmd == "joint":
        mover = arm.move_relative if args.relative else arm.move_to
        print_positions(mover({args.name: args.value}, args.duration))

    elif cmd == "gripper":
        value = {"open": 100.0, "close": 0.0}.get(args.value.lower())
        if value is None:
            value = float(args.value)
        print_positions(arm.set_gripper(value, args.duration))

    elif cmd == "home":
        print_positions(arm.home(args.duration))

    elif cmd == "torque":
        if args.state == "off":
            arm.torque_off()
            print("Torque OFF - the arm is limp and can be moved by hand.")
        else:
            arm.torque_on()
            print("Torque ON - holding current pose.")

    elif cmd == "pose":
        if args.action == "list":
            for name, pose in SO101Arm.load_poses().items():
                print(f"{name}: {pose}")
        elif not args.name:
            print("Pose name required, e.g. 'pose save rest'")
        elif args.action == "save":
            print(f"Saved '{args.name}': {arm.save_pose(args.name)}")
        else:
            print_positions(arm.go_to_pose(args.name, args.duration))

    elif cmd == "gains":
        values = {key: getattr(args, key) for key in GAIN_REGISTERS if getattr(args, key) is not None}
        if args.joint and values:
            for joint in JOINTS if args.joint == "all" else (args.joint,):
                written = arm.set_gains(joint, **values)
                if args.save:
                    arm.save_gains(joint, **written)
            if not args.save:
                print("Applied until next connect (add --save to keep).")
        elif args.joint:
            print("Nothing to set: pass e.g. --p 24 --d 40")
            return
        print(f"  {'joint':<14}" + "".join(f"{key:>14}" for key in GAIN_REGISTERS))
        for joint, row in arm.get_gains().items():
            print(f"  {joint:<14}" + "".join(f"{row[key]:>14}" for key in GAIN_REGISTERS))

    elif cmd == "speed":
        arm.speed = args.value
        print(f"Default speed: {arm.speed} deg/s")


def shell(arm: SO101Arm) -> None:
    parser = build_command_parser()
    print("SO-101 shell. Commands: read, move, joint, gripper, home, torque, pose, gains, speed. "
          "'help' for usage, 'quit' to exit.")
    while True:
        try:
            line = input("so101> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line in ("quit", "exit", "q"):
            break
        if line in ("help", "?"):
            parser.print_help()
            continue
        try:
            run_command(arm, parser.parse_args(shlex.split(line)))
        except SystemExit:
            pass  # argparse already printed the error
        except KeyboardInterrupt:
            print("\nInterrupted - arm holds at its last set-point.")
        except Exception as e:  # keep the shell alive on bus/limit errors
            print(f"Error: {e}")


def main(argv: list[str] | None = None) -> None:
    argv = sys.argv[1:] if argv is None else argv

    top = argparse.ArgumentParser(
        description="Control the SO-101 follower arm via LeRobot.",
        epilog="Arm commands: read, move, joint, gripper, home, torque, pose, gains. Run '<command> -h' for details.",
    )
    top.add_argument("--port", default=DEFAULT_PORT, help=f"serial port (default: {DEFAULT_PORT})")
    top.add_argument("--id", default=DEFAULT_ID, help=f"calibration id (default: {DEFAULT_ID})")
    top.add_argument("--speed", type=float, default=45.0, help="default speed, deg/s")
    top.add_argument("--release", action="store_true", help="disable torque when the program exits")
    top.add_argument("-v", "--verbose", action="store_true")
    top.add_argument("command", nargs="?", default="shell",
                     help="ports | calibrate | shell | an arm command (see below)")
    top.add_argument("rest", nargs=argparse.REMAINDER, help=argparse.SUPPRESS)
    args = top.parse_args(argv)

    logging.basicConfig(level=logging.INFO if args.verbose else logging.WARNING,
                        format="%(levelname)s %(message)s")

    if args.command == "ports":
        ports = list_serial_ports()
        print("\n".join(ports) if ports else "No serial ports found. Is the arm's USB cable connected?")
        return

    arm = SO101Arm(port=args.port, robot_id=args.id, speed=args.speed, release_on_exit=args.release)

    if args.command == "calibrate":
        try:
            arm.calibrate()
        finally:
            arm.disconnect()
        return

    command = None
    if args.command != "shell":
        command = build_command_parser().parse_args([args.command, *args.rest])

    with arm:
        if command is None:
            shell(arm)
        else:
            run_command(arm, command)


if __name__ == "__main__":
    main()
