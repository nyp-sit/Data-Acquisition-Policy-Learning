"""Scripted demo: home, wave the base, nod the wrist, roll, open/close the gripper, back home.

Run with the arm clear of obstacles:
    python demo_sequence.py --port COM3 --id my_awesome_follower_arm
"""

import argparse

from so101_arm import DEFAULT_ID, DEFAULT_PORT, SO101Arm


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--port", default=DEFAULT_PORT)
    parser.add_argument("--id", default=DEFAULT_ID)
    parser.add_argument("--speed", type=float, default=40.0, help="deg/s")
    args = parser.parse_args()

    with SO101Arm(port=args.port, robot_id=args.id, speed=args.speed) as arm:
        print("Start:", arm.get_positions())

        print("Home")
        arm.home(duration=3.0)

        print("Wave shoulder_pan")
        for angle in (30, -30, 30, 0):
            arm.move_joint("shoulder_pan", angle)

        print("Nod wrist_flex")
        for angle in (25, -25, 0):
            arm.move_joint("wrist_flex", angle)

        print("Roll wrist_roll")
        arm.move_joint("wrist_roll", 90)
        arm.move_joint("wrist_roll", 0)

        print("Gripper open/close")
        arm.open_gripper(duration=1.0)
        arm.close_gripper(duration=1.0)

        # Joint sign conventions depend on calibration; small angles keep this safe either way.
        print("Combined move: shoulder_lift + elbow_flex + wrist_flex")
        arm.move_to({"shoulder_lift": 20, "elbow_flex": -20, "wrist_flex": 10}, duration=2.5)

        print("Back home")
        arm.home(duration=3.0)
        print("End:", arm.get_positions())


if __name__ == "__main__":
    main()
