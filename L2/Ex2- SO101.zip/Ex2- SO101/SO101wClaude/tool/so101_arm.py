"""High-level motion control for the SO-101 follower arm, built on LeRobot.

The SO-101 follower has six Feetech STS3215 servos on one serial bus (1 Mbps):

    id  joint           unit
    1   shoulder_pan    degrees (0 = middle of calibrated range)
    2   shoulder_lift   degrees
    3   elbow_flex      degrees
    4   wrist_flex      degrees
    5   wrist_roll      degrees
    6   gripper         percent, 0..100 of the calibrated range

LeRobot's ``SO101Follower.send_action`` writes the goal positions in a single step and does
not clamp degree targets to the calibrated range. This wrapper adds:

  * soft joint limits derived from the calibration file,
  * smooth, time-interpolated moves (``move_to``) instead of jumping to the target,
  * partial commands (only the joints you name move, the rest hold position),
  * torque on/off and named poses for "teach by hand" workflows.

Example:
    from so101_arm import SO101Arm

    with SO101Arm(port="COM3", robot_id="my_awesome_follower_arm") as arm:
        print(arm.get_positions())
        arm.move_to({"shoulder_pan": 20, "elbow_flex": -10}, duration=2.0)
        arm.open_gripper()
        arm.close_gripper()
        arm.home()
"""

from __future__ import annotations

import json
import logging
import math
import os
import time
from pathlib import Path

from lerobot.robots.so_follower import SO101Follower, SO101FollowerConfig
from lerobot.utils.robot_utils import precise_sleep

logger = logging.getLogger(__name__)

JOINTS = ("shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll", "gripper")
GRIPPER = "gripper"

# STS3215: 4096 ticks per revolution.
_TICKS_PER_REV = 4095

DEFAULT_PORT = os.getenv("SO101_PORT", "COM3")
DEFAULT_ID = os.getenv("SO101_ID", "my_awesome_follower_arm")
DEFAULT_POSES_FILE = Path(__file__).with_name("poses.json")
DEFAULT_GAINS_FILE = Path(__file__).with_name("gains.json")

# Servo tuning knobs -> (Feetech STS3215 register, allowed range).
#   p             stiffness: position-loop proportional gain (LeRobot default 16, factory 32)
#   d             damping:   position-loop derivative gain   (LeRobot default 32)
#   i             integral gain, removes steady sag under load (LeRobot default 0)
#   torque_limit  max output torque in 0.1 % of stall torque (1000 = 100 %); RAM, not saved in servo
#   acceleration  servo's internal accel ramp, 100 steps/s^2 per unit; 0 = no ramp (LeRobot sets 254)
GAIN_REGISTERS = {
    "p": ("P_Coefficient", 0, 254),
    "d": ("D_Coefficient", 0, 254),
    "i": ("I_Coefficient", 0, 254),
    "torque_limit": ("Torque_Limit", 0, 1000),
    "acceleration": ("Acceleration", 0, 254),
}


class SO101Arm:
    """Thin, safety-minded wrapper around LeRobot's ``SO101Follower``.

    Args:
        port: Serial port of the follower's controller board (e.g. ``"COM3"`` or ``"/dev/ttyACM0"``).
        robot_id: Calibration id used with ``lerobot-calibrate --robot.id=...``.
        speed: Default joint speed in degrees (or gripper %) per second, used when a move has no
            explicit duration.
        fps: Rate at which interpolated set-points are streamed to the servos.
        limit_margin_deg: Keep body joints this many degrees inside the calibrated range.
        max_relative_target: Optional per-step clip passed to LeRobot (extra safety net).
        release_on_exit: Disable torque when disconnecting. Defaults to False so the arm holds its
            pose instead of collapsing onto the table.
        calibration_dir: Override where LeRobot looks for ``<robot_id>.json``.
        gains: Per-joint servo tuning applied after every connect, e.g.
            ``{"shoulder_lift": {"p": 24, "d": 40}, "gripper": {"torque_limit": 400}}``.
            When None, the gains are loaded from ``gains_file`` if it exists.
        gains_file: JSON file with the same structure as ``gains``.
    """

    def __init__(
        self,
        port: str = DEFAULT_PORT,
        robot_id: str = DEFAULT_ID,
        speed: float = 45.0,
        fps: float = 50.0,
        limit_margin_deg: float = 2.0,
        max_relative_target: float | None = None,
        release_on_exit: bool = False,
        calibration_dir: str | Path | None = None,
        gains: dict[str, dict[str, int]] | None = None,
        gains_file: str | Path = DEFAULT_GAINS_FILE,
    ):
        config = SO101FollowerConfig(
            port=port,
            id=robot_id,
            use_degrees=True,
            max_relative_target=max_relative_target,
            disable_torque_on_disconnect=release_on_exit,
            calibration_dir=Path(calibration_dir) if calibration_dir else None,
        )
        self.robot = SO101Follower(config)
        self.robot.configure = self._configure_without_jump
        self.speed = speed
        self.fps = fps
        self.limit_margin_deg = limit_margin_deg
        self.gains_file = Path(gains_file)
        self.gains = gains if gains is not None else self.load_gains(self.gains_file)

    # ------------------------------------------------------------------ connection

    def connect(self, calibrate: bool = True) -> None:
        """Open the serial bus. Runs LeRobot's interactive calibration if none matches the motors."""
        self.robot.connect(calibrate=calibrate)
        # LeRobot's connect() resets P/I/D to the same values on every joint; apply ours on top.
        for joint, values in self.gains.items():
            self.set_gains(joint, **values)
        logger.info("Connected. Joint limits: %s", self.joint_limits)

    def disconnect(self) -> None:
        if self.robot.is_connected:
            self.robot.disconnect()

    def calibrate(self) -> None:
        """Run LeRobot's interactive calibration and save it under ``robot_id``."""
        self.robot.connect(calibrate=False)
        self.robot.calibrate()

    @property
    def is_connected(self) -> bool:
        return self.robot.is_connected

    def __enter__(self) -> SO101Arm:
        self.connect()
        return self

    def __exit__(self, *exc) -> None:
        self.disconnect()

    # ------------------------------------------------------------------ state

    @property
    def joint_limits(self) -> dict[str, tuple[float, float]]:
        """Soft (min, max) per joint derived from the calibration ranges."""
        limits = {}
        for name, cal in self.robot.calibration.items():
            if name == GRIPPER:
                limits[name] = (0.0, 100.0)
                continue
            half = (cal.range_max - cal.range_min) / 2 * 360 / _TICKS_PER_REV
            margin = min(self.limit_margin_deg, half)
            limits[name] = (-half + margin, half - margin)
        return limits

    def get_positions(self) -> dict[str, float]:
        """Current joint positions keyed by joint name (degrees, gripper in %)."""
        obs = self.robot.get_observation()
        return {name: float(obs[f"{name}.pos"]) for name in JOINTS}

    def clamp(self, targets: dict[str, float], warn: bool = True) -> dict[str, float]:
        """Clip targets to the soft joint limits, warning (if ``warn``) when a value is changed."""
        limits = self.joint_limits
        clamped = {}
        for name, value in targets.items():
            if name not in JOINTS:
                raise ValueError(f"Unknown joint '{name}'. Valid joints: {', '.join(JOINTS)}")
            lo, hi = limits[name]
            safe = min(hi, max(lo, float(value)))
            if warn and not math.isclose(safe, value):
                logger.warning("%s target %.1f clipped to %.1f (limits %.1f..%.1f)", name, value, safe, lo, hi)
            clamped[name] = safe
        return clamped

    # ------------------------------------------------------------------ motion

    def send(self, targets: dict[str, float], warn: bool = True) -> dict[str, float]:
        """Write goal positions immediately (no interpolation). Returns what was sent (after clipping)."""
        action = {f"{name}.pos": value for name, value in self.clamp(targets, warn).items()}
        sent = self.robot.send_action(action)
        return {key.removesuffix(".pos"): value for key, value in sent.items()}

    def move_to(self, targets: dict[str, float], duration: float | None = None) -> dict[str, float]:
        """Move the named joints smoothly to absolute targets; other joints hold still.

        If ``duration`` is None it is derived from the largest joint travel and ``self.speed``.
        Returns the final positions read back from the arm.
        """
        goal = self.clamp(targets)
        start = {name: value for name, value in self.get_positions().items() if name in goal}
        travel = max((abs(goal[n] - start[n]) for n in goal), default=0.0)
        if duration is None:
            duration = max(0.3, travel / self.speed)

        steps = max(1, round(duration * self.fps))
        period = duration / steps
        t0 = time.perf_counter()
        for i in range(1, steps + 1):
            # Cosine ease-in/ease-out: zero velocity at both ends.
            s = 0.5 - 0.5 * math.cos(math.pi * i / steps)
            self.robot.send_action({f"{n}.pos": start[n] + (goal[n] - start[n]) * s for n in goal})
            precise_sleep(max(0.0, t0 + i * period - time.perf_counter()))
        return self.get_positions()

    def move_relative(self, deltas: dict[str, float], duration: float | None = None) -> dict[str, float]:
        """Move the named joints by the given offsets from their current position."""
        current = self.get_positions()
        return self.move_to({name: current[name] + delta for name, delta in deltas.items()}, duration)

    def move_joint(self, name: str, value: float, duration: float | None = None) -> dict[str, float]:
        return self.move_to({name: value}, duration)

    def set_gripper(self, percent: float, duration: float | None = None) -> dict[str, float]:
        return self.move_to({GRIPPER: percent}, duration)

    def open_gripper(self, percent: float = 100.0, duration: float | None = None) -> dict[str, float]:
        return self.set_gripper(percent, duration)

    def close_gripper(self, percent: float = 0.0, duration: float | None = None) -> dict[str, float]:
        return self.set_gripper(percent, duration)

    def home(self, duration: float | None = None) -> dict[str, float]:
        """Go to the calibration 'middle' pose: every body joint at 0 degrees. Gripper unchanged."""
        return self.move_to({name: 0.0 for name in JOINTS if name != GRIPPER}, duration)

    # ------------------------------------------------------------------ torque

    def torque_off(self) -> None:
        """Release all servos so the arm can be moved by hand. Support the arm first!"""
        self.robot.bus.disable_torque()

    def torque_on(self) -> None:
        """Re-enable all servos, holding the current pose."""
        self._sync_goal_to_present()
        self.robot.bus.enable_torque()

    # ------------------------------------------------------------------ stiffness / damping

    def set_gains(self, joint: str, **values: int) -> dict[str, int]:
        """Tune one joint's servo, e.g. ``set_gains("elbow_flex", p=24, d=40, torque_limit=800)``.

        Keys: p (stiffness), d (damping), i, torque_limit, acceleration (see GAIN_REGISTERS).
        Written live with torque kept on, so the arm does not sag. Not persisted - use
        ``save_gains`` (or pass ``gains=``) to re-apply them on the next connect.
        """
        if joint not in JOINTS:
            raise ValueError(f"Unknown joint '{joint}'. Valid joints: {', '.join(JOINTS)}")
        unknown = set(values) - set(GAIN_REGISTERS)
        if unknown:
            raise ValueError(f"Unknown gain(s) {sorted(unknown)}. Valid: {', '.join(GAIN_REGISTERS)}")

        bus = self.robot.bus
        written = {}
        # P/I/D live in the servo's EEPROM area, which is write-protected while Lock=1.
        bus.write("Lock", joint, 0)
        try:
            for key, value in values.items():
                register, lo, hi = GAIN_REGISTERS[key]
                written[key] = min(hi, max(lo, int(value)))
                if written[key] != value:
                    logger.warning("%s %s=%s clipped to %s", joint, key, value, written[key])
                bus.write(register, joint, written[key])
        finally:
            bus.write("Lock", joint, 1)
        return written

    def get_gains(self) -> dict[str, dict[str, int]]:
        """Read back the tuning registers of every joint."""
        bus = self.robot.bus
        per_register = {key: bus.sync_read(reg) for key, (reg, _, _) in GAIN_REGISTERS.items()}
        return {joint: {key: int(per_register[key][joint]) for key in GAIN_REGISTERS} for joint in JOINTS}

    @staticmethod
    def load_gains(path: str | Path = DEFAULT_GAINS_FILE) -> dict[str, dict[str, int]]:
        path = Path(path)
        return json.loads(path.read_text()) if path.is_file() else {}

    def save_gains(self, joint: str, **values: int) -> None:
        """Merge values into the gains file so they are re-applied on every connect."""
        self.gains.setdefault(joint, {}).update(values)
        self.gains_file.write_text(json.dumps(self.gains, indent=2))

    def _sync_goal_to_present(self) -> None:
        """Make each servo's goal its current position, so enabling torque can't cause a jump."""
        present = self.robot.bus.sync_read("Present_Position", normalize=False)
        self.robot.bus.sync_write("Goal_Position", present, normalize=False)

    def _configure_without_jump(self) -> None:
        # LeRobot's configure() ends by re-enabling torque. If the arm was moved by hand while limp,
        # the servos still hold their old goal and would snap back to it, so sync the goal first.
        self._sync_goal_to_present()
        type(self.robot).configure(self.robot)

    # ------------------------------------------------------------------ named poses

    @staticmethod
    def load_poses(path: str | Path = DEFAULT_POSES_FILE) -> dict[str, dict[str, float]]:
        path = Path(path)
        return json.loads(path.read_text()) if path.is_file() else {}

    def save_pose(self, name: str, path: str | Path = DEFAULT_POSES_FILE) -> dict[str, float]:
        """Record the current joint positions under ``name`` in a JSON file."""
        poses = self.load_poses(path)
        poses[name] = {joint: round(value, 2) for joint, value in self.get_positions().items()}
        Path(path).write_text(json.dumps(poses, indent=2))
        return poses[name]

    def go_to_pose(
        self, name: str, duration: float | None = None, path: str | Path = DEFAULT_POSES_FILE
    ) -> dict[str, float]:
        poses = self.load_poses(path)
        if name not in poses:
            raise KeyError(f"No pose named '{name}' in {path}. Saved poses: {', '.join(poses) or 'none'}")
        return self.move_to(poses[name], duration)


def list_serial_ports() -> list[str]:
    """Serial ports currently visible to the OS (the arm shows up as COMx on Windows)."""
    from serial.tools import list_ports

    return [f"{p.device}  {p.description}" for p in list_ports.comports()]
