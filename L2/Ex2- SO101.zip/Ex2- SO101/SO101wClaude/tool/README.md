# SO-101 arm control tools

These Python tools command the SO-101 **follower** arm. They're built on the LeRobot API
(`lerobot.robots.so_follower.SO101Follower`) in `../lerobot`.

| File | Purpose |
| --- | --- |
| `so101_arm.py` | `SO101Arm` class: smooth moves, soft joint limits, gripper, torque, named poses |
| `so101_cli.py` | Command line and interactive shell built on `SO101Arm` |
| `demo_sequence.py` | Scripted motion demo |
| `arm_forward_back.py` | Lab 1: swing one joint with a live monitor, per-swing summary and CSV log (see `labs\lab1_arm_movement.md`) |
| `joint_monitor.py` | Live table of the servo feedback: position, target, error, velocity, load, current, temperature |
| `plot_joint_log.py` | Plot a CSV log from `logs\` (needs `pip install matplotlib`) |
| `solutions\gripper_open_close.py` | Lab 1 exercise solution |
| `poses.json` | Created when you `pose save` something |
| `gains.json` | Per-joint stiffness/damping, created by `gains ... --save` |

## Joints and units

| ID | Joint | Unit |
| --- | --- | --- |
| 1 | `shoulder_pan` | degrees, 0 = middle of calibrated range |
| 2 | `shoulder_lift` | degrees |
| 3 | `elbow_flex` | degrees |
| 4 | `wrist_flex` | degrees |
| 5 | `wrist_roll` | degrees |
| 6 | `gripper` | 0–100 % of calibrated range |

All joints at 0° is the "middle" pose you held the arm in during calibration.
Targets are clipped to the calibrated range minus 2°. Run `read` to see the limits.

## One-time setup

Run these in the `lerobot` conda environment:

```powershell
conda activate lerobot
cd C:\SO101wClaude\tool

python so101_cli.py ports              # or: lerobot-find-port
$env:SO101_PORT = "COM3"               # your port
$env:SO101_ID   = "my_awesome_follower_arm"

# Only needed if motor IDs were never set:
lerobot-setup-motors --robot.type=so101_follower --robot.port=$env:SO101_PORT

python so101_cli.py calibrate          # same as lerobot-calibrate; saves <id>.json
```

The calibration file is saved to `%USERPROFILE%\.cache\huggingface\lerobot\calibration\robots\so_follower\<id>.json`.

## Commands

```powershell
python so101_cli.py read
python so101_cli.py move --shoulder_pan 20 --elbow_flex -15 --duration 2
python so101_cli.py move --wrist_flex 10 --relative
python so101_cli.py joint wrist_roll 45
python so101_cli.py gripper open        # close | 0..100
python so101_cli.py home
python so101_cli.py torque off          # arm goes limp. Support it first!
python so101_cli.py pose save rest      # teach: torque off, place by hand, save
python so101_cli.py pose go rest
python so101_cli.py shell               # interactive, keeps one connection open
```

By default, torque **stays on** when the program exits, so the arm holds its pose instead of dropping.
To release it on exit, pass `--release` or use `torque off`.

## Stiffness and damping per joint

The STS3215 servos have no true impedance mode. These servo registers act as the tuning knobs:

| Key | Register | Effect | Range | LeRobot default |
| --- | --- | --- | --- | --- |
| `p` | `P_Coefficient` | **stiffness**: how hard the joint pulls back to its target | 0–254 | 16 |
| `d` | `D_Coefficient` | **damping**: resists velocity, reduces overshoot and oscillation | 0–254 | 32 |
| `i` | `I_Coefficient` | removes the steady sag under load (can cause slow oscillation) | 0–254 | 0 |
| `torque_limit` | `Torque_Limit` | caps the output torque, in 0.1 % units (`1000` = 100 %) | 0–1000 | 1000 (gripper 500) |
| `acceleration` | `Acceleration` | the servo's own acceleration ramp, in units of 100 steps/s²; `0` = none | 0–254 | 254 |

LeRobot sets `p`/`i`/`d` to the same values on every joint at each `connect()`.
This tool then applies your per-joint values from `gains.json`.

```powershell
python so101_cli.py gains                                      # show current values
python so101_cli.py gains shoulder_lift --p 28 --d 40 --save   # stiffer joint that carries gravity load
python so101_cli.py gains wrist_roll --p 12 --save             # softer, more compliant wrist
python so101_cli.py gains all --torque_limit 600               # softer arm, until the next connect
```

`gains.json` looks like this:
```json
{ "shoulder_lift": {"p": 28, "d": 40}, "gripper": {"torque_limit": 400} }
```

Tuning tips:
- Change one joint at a time, in steps of 4–8.
- If a joint buzzes or oscillates, lower `p` or `d`. If it overshoots, raise `d`.
- If it sags under its own weight, raise `p`, or add a small `i` (1–4).
- `torque_limit` is the safest way to make the arm compliant for contact tasks.

## Python API

```python
from so101_arm import SO101Arm

with SO101Arm(port="COM3", robot_id="my_awesome_follower_arm", speed=45) as arm:
    print(arm.get_positions())
    arm.move_to({"shoulder_pan": 20, "wrist_flex": -10}, duration=2.0)  # unnamed joints hold
    arm.move_relative({"elbow_flex": 5})
    arm.open_gripper(); arm.close_gripper()
    arm.home()
    arm.send({"wrist_roll": 30})  # raw single write, no interpolation (for your own control loops)
    arm.set_gains("elbow_flex", p=24, d=40)   # stiffness / damping, live
    print(arm.get_gains())

# Per-joint gains applied on every connect (overrides gains.json):
arm = SO101Arm(port="COM3", gains={"shoulder_lift": {"p": 28, "d": 40}, "wrist_roll": {"p": 12}})
```

## Safety notes

- Keep the first moves small and slow (`--speed 20`). Sign directions depend on your calibration.
- `home` moves every body joint to 0°. Check that the path is clear.
- Press Ctrl+C in the shell to stop a move. The arm holds at its last set-point.
- The gripper's torque is limited to 50% by LeRobot to avoid burning out the motor.
