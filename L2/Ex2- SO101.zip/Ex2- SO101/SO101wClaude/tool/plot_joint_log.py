"""plot_joint_log.py - plot a joint log written by arm_forward_back.py (or your copy of it).

One row per joint: position vs target on the left, load (% of max torque) on the right.
The arm does not need to be connected.

    & $py tool\\plot_joint_log.py                         # newest CSV in logs\\, opens a window
    & $py tool\\plot_joint_log.py logs\\<file>.csv         # a specific log
    & $py tool\\plot_joint_log.py --out joints.png        # save an image instead
"""

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt

JOINTS = ("shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll", "gripper")
LOG_DIR = Path(__file__).resolve().parent.parent / "logs"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("csv", nargs="?", type=Path, help="log file (default: newest in logs\\)")
    parser.add_argument("--out", type=Path, help="save to this image file instead of opening a window")
    args = parser.parse_args()

    path = args.csv
    if path is None:
        logs = sorted(LOG_DIR.glob("*.csv"), key=lambda p: p.stat().st_mtime)
        if not logs:
            raise SystemExit(f"No CSV logs in {LOG_DIR}. Run arm_forward_back.py first.")
        path = logs[-1]

    with path.open(newline="") as f:
        rows = list(csv.DictReader(f))
    t = [float(r["t"]) for r in rows]

    fig, axes = plt.subplots(len(JOINTS), 2, figsize=(13, 2.1 * len(JOINTS)), sharex=True)
    fig.suptitle(path.name)
    for i, j in enumerate(JOINTS):
        unit = "%" if j == "gripper" else "deg"
        left, right = axes[i]
        left.plot(t, [float(r[f"target_{j}"]) for r in rows], color="grey", lw=1.5, label="target")
        left.plot(t, [float(r[f"pos_{j}"]) for r in rows], color="tab:green", lw=1.2, label="position")
        left.set_ylabel(f"{j}\n({unit})", fontsize=8)
        right.plot(t, [float(r[f"load_{j}"]) for r in rows], color="tab:red", lw=1.0)
        right.axhline(0, color="black", lw=0.5)
        right.set_ylabel("load %", fontsize=8)
        for ax in (left, right):
            ax.grid(alpha=0.3)
            ax.tick_params(labelsize=7)
    axes[0][0].legend(fontsize=7, loc="upper right")
    axes[0][0].set_title("position vs target", fontsize=9)
    axes[0][1].set_title("load (% of max torque)", fontsize=9)
    for ax in axes[-1]:
        ax.set_xlabel("time (s)")
    fig.tight_layout()

    if args.out:
        fig.savefig(args.out, dpi=120)
        print(f"Saved {args.out}")
    else:
        plt.show()


if __name__ == "__main__":
    main()
