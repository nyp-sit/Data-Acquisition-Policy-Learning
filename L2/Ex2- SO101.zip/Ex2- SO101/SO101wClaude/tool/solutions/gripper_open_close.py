"""gripper_open_close.py - open and close the gripper of the REAL SO-101 arm.

Lab 1 exercise solution: arm_forward_back.py with the five changes from labs\\lab1_arm_movement.md.

Real-arm version of the Isaac Sim test (SO101wClaudeIsaac\\docs\\test-so101-arm-movement.md).
The program:
  1. moves the arm smoothly to START_POSE (after you press ENTER),
  2. opens JOINT by AMPLITUDE and closes it again, CYCLES times,
  3. shows a live joint table and prints a summary after every swing,
  4. prints a summary of every joint, saves a CSV log in logs\\,
  5. moves the arm back to the pose it started in.

Run from C:\\SO101wClaude:
    & $py tool\\gripper_open_close.py
Ctrl+C stops the motion at once; the arm holds where it is.
"""

import argparse
import csv
import math
import sys
import time
from datetime import datetime
from pathlib import Path

TOOL_DIR = next(p for p in Path(__file__).resolve().parents if p.name == "tool")
sys.path.insert(0, str(TOOL_DIR))

from lerobot.utils.robot_utils import precise_sleep  # noqa: E402

from joint_monitor import LiveDisplay, read_joints, read_load_limits, render_table  # noqa: E402
from so101_arm import DEFAULT_ID, DEFAULT_PORT, GRIPPER, JOINTS, SO101Arm  # noqa: E402

# ----------------------------------------------------------------------------- 1. settings
CYCLES = 5                 # 5 open/close cycles
PERIOD_S = 3.0             # 3 s per cycle
AMPLITUDE = 60.0           # open by 60 % of the gripper's calibrated range
JOINT = "gripper"          # shoulder_pan, shoulder_lift, elbow_flex, wrist_flex, wrist_roll or gripper

# Pose the swing is centred on. Degrees; 0 = middle of the calibrated range (the pose you held the
# arm in during calibration). None = leave that joint where it is when the program starts.
START_POSE = {
    "shoulder_pan": 0.0,
    "shoulder_lift": 0.0,
    "elbow_flex": 0.0,
    "wrist_flex": 0.0,
    "wrist_roll": 0.0,
    "gripper": 2.0,        # closed (check which end is closed in Step E1)
}
MOVE_TIME_S = 3.0          # time to move to START_POSE, and back at the end
RETURN_TO_START = True     # finish in the pose the arm started in (e.g. folded rest)

# ----------------------------------------------------------------------------- 2. monitoring and safety
RATE_HZ = 30               # commands and feedback samples per second
SHOW_MONITOR = True        # live joint table in the terminal. False = summaries and CSV only
SAVE_CSV = True            # save the joint log to logs\ when the run ends
SATURATION_FRACTION = 0.95 # |load| at or above this fraction of the servo's Torque_Limit counts as saturated
MAX_TEMP_C = 55            # stop if any servo gets hotter than this (the STS3215 cuts out near 70 C)

PROGRAM = "gripper_open_close"
LOG_DIR = TOOL_DIR.parent / "logs"
UNIT = "%" if JOINT == GRIPPER else "deg"


# ----------------------------------------------------------------------------- 3. connect
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--port", default=DEFAULT_PORT, help=f"serial port (default {DEFAULT_PORT})")
    parser.add_argument("--id", default=DEFAULT_ID, help=f"calibration id (default {DEFAULT_ID})")
    parser.add_argument("--yes", action="store_true", help="don't ask before moving")
    return parser.parse_args()


# ----------------------------------------------------------------------------- 4. move to the start pose
def go_to_start(arm: SO101Arm, ask: bool) -> tuple[dict[str, float], dict[str, float]]:
    """Show the planned move, wait for ENTER, move. Returns (pose at program start, swing centre pose)."""
    initial = arm.get_positions()
    start = {j: initial[j] if START_POSE.get(j) is None else START_POSE[j] for j in JOINTS}
    start = arm.clamp(start)
    lo, hi = arm.joint_limits[JOINT]

    print(f"[{PROGRAM}] planned move to START_POSE ({MOVE_TIME_S:g} s):")
    for j in JOINTS:
        print(f"    {j:<14} {initial[j]:+7.1f} -> {start[j]:+7.1f}")
    # Sample one period of the motion to find the range JOINT will be asked to cover.
    path = [target_at(PERIOD_S * k / 100, start[JOINT]) for k in range(101)]
    print(f"[{PROGRAM}] then {JOINT} moves between {min(path):+.1f} and {max(path):+.1f} {UNIT}, "
          f"{CYCLES} x {PERIOD_S}s")
    if min(path) < lo or max(path) > hi:
        print(f"[{PROGRAM}] WARNING: that leaves {JOINT}'s range {lo:+.1f} .. {hi:+.1f}; targets will be clipped")
    if ask:
        input("Clear the area around the arm, keep a hand near the power switch. ENTER = start, Ctrl+C = cancel ")

    arm.move_to(start, duration=MOVE_TIME_S)
    return initial, start


# ----------------------------------------------------------------------------- 5. per-swing summary
def new_cycle_stats() -> dict:
    return {"lo": math.inf, "hi": -math.inf, "err": 0.0, "sat": 0, "clip": 0, "n": 0}


def print_cycle_summary(display: LiveDisplay, cycle: int, s: dict, centre: float) -> None:
    n = max(1, s["n"])
    clipped = f"  clipped {100 * s['clip'] / n:.0f}% of steps" if s["clip"] else ""
    display.log(
        f"[{PROGRAM}] cycle {cycle}/{CYCLES}  {JOINT} reached {s['lo'] - centre:+.1f} .. "
        f"{s['hi'] - centre:+.1f} {UNIT} from start (commanded 0 .. +{AMPLITUDE})  "
        f"max error {s['err']:.1f} {UNIT}  load saturated {100 * s['sat'] / n:.0f}% of steps{clipped}"
    )


# ----------------------------------------------------------------------------- 6. joint log
def log_row(step: int, t: float, sample: dict, targets: dict) -> dict:
    row = {"step": step, "t": round(t, 4)}
    for j in JOINTS:
        row[f"pos_{j}"] = round(sample[j]["pos"], 3)
        row[f"target_{j}"] = round(targets[j], 3)
        row[f"vel_{j}"] = round(sample[j]["vel"], 2)
        row[f"load_{j}"] = round(sample[j]["load"], 1)
        row[f"current_{j}"] = round(sample[j]["current"], 1)
        row[f"temp_{j}"] = sample[j]["temp"]
    return row


def save_csv(rows: list[dict]) -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    path = LOG_DIR / f"{PROGRAM}_{datetime.now():%Y%m%d_%H%M%S}.csv"
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return path


def print_joint_summary(rows: list[dict], load_limits: dict[str, float]) -> None:
    print(f"[{PROGRAM}] joint summary over {len(rows)} steps:")
    print(f"  {'joint':<15}{'min pos':>9}{'max pos':>9}{'max |err|':>11}{'max |load|%':>13}{'sat %':>7}{'max C':>7}")
    for j in JOINTS:
        pos = [r[f"pos_{j}"] for r in rows]
        err = max(abs(r[f"target_{j}"] - r[f"pos_{j}"]) for r in rows)
        load = [abs(r[f"load_{j}"]) for r in rows]
        sat = sum(v >= SATURATION_FRACTION * load_limits[j] for v in load)
        temps = [r[f"temp_{j}"] for r in rows if not math.isnan(r[f"temp_{j}"])]
        print(f"  {j:<15}{min(pos):+9.1f}{max(pos):+9.1f}{err:11.1f}{max(load):13.1f}"
              f"{100 * sat / len(rows):7.0f}{max(temps, default=math.nan):7.0f}")


# ----------------------------------------------------------------------------- 7. the motion
def target_at(t: float, centre: float) -> float:
    """Where JOINT should be t seconds after the swing started."""
    # One-way wave: closed -> open (+A) -> closed once every PERIOD_S seconds, zero speed at both ends.
    return centre + AMPLITUDE * 0.5 * (1 - math.cos(2 * math.pi * t / PERIOD_S))


# ----------------------------------------------------------------------------- 8. main loop
def main() -> None:
    args = parse_args()
    if JOINT not in JOINTS:
        raise ValueError(f"JOINT = {JOINT!r} is not one of {JOINTS}")

    rows: list[dict] = []
    with SO101Arm(port=args.port, robot_id=args.id) as arm:
        limits, load_limits = arm.joint_limits, read_load_limits(arm)
        try:
            initial, targets = go_to_start(arm, ask=not args.yes)
        except KeyboardInterrupt:
            print(f"\n[{PROGRAM}] cancelled - arm holds where it is")
            return
        centre = targets[JOINT]

        display = LiveDisplay(SHOW_MONITOR)
        display.log(f"Started: {CYCLES} x {PERIOD_S}s open/close cycles of {JOINT} (0 .. +{AMPLITUDE} {UNIT}), "
                    f"~{CYCLES * PERIOD_S:.0f}s total. Ctrl+C = stop")
        stats, cycle, step = new_cycle_stats(), 0, 0
        temps: dict[str, float] = {}
        next_temp_t, next_draw_t = 0.0, 0.0
        finished = False
        t0 = time.perf_counter()
        try:
            while (t := time.perf_counter() - t0) < CYCLES * PERIOD_S:
                # Command the moving joint (clipped to its calibrated range), then read every joint back.
                wanted = target_at(t, centre)
                targets[JOINT] = arm.send({JOINT: wanted}, warn=False)[JOINT]
                read_temp = t >= next_temp_t
                sample = read_joints(arm, with_temperature=read_temp)
                if read_temp:
                    next_temp_t += 1.0
                    temps = {j: sample[j]["temp"] for j in JOINTS}
                    hottest = max(temps, key=temps.get)
                    if temps[hottest] > MAX_TEMP_C:
                        raise RuntimeError(f"{hottest} is at {temps[hottest]:.0f} C (> {MAX_TEMP_C} C)")
                for j in JOINTS:
                    sample[j]["temp"] = temps.get(j, math.nan)
                rows.append(log_row(step, t, sample, targets))

                if int(t // PERIOD_S) > cycle:
                    cycle += 1
                    print_cycle_summary(display, cycle, stats, centre)
                    stats = new_cycle_stats()
                pos = sample[JOINT]["pos"]
                stats["lo"], stats["hi"] = min(stats["lo"], pos), max(stats["hi"], pos)
                stats["err"] = max(stats["err"], abs(targets[JOINT] - pos))
                stats["sat"] += abs(sample[JOINT]["load"]) >= SATURATION_FRACTION * load_limits[JOINT]
                stats["clip"] += not math.isclose(targets[JOINT], wanted, abs_tol=1e-6)
                stats["n"] += 1

                if t >= next_draw_t:
                    next_draw_t += 0.2
                    header = f"SO-101  {PROGRAM} running  t={t:5.1f}/{CYCLES * PERIOD_S:.0f}s  cycle {cycle + 1}/{CYCLES}"
                    display.draw(render_table(sample, targets, limits, load_limits, header, highlight=JOINT))

                step += 1
                precise_sleep(max(0.0, t0 + step / RATE_HZ - time.perf_counter()))
            finished = True
            print_cycle_summary(display, CYCLES, stats, centre)
            display.log(f"[{PROGRAM}] done: {CYCLES} cycles, average {len(rows) / (time.perf_counter() - t0):.0f} "
                        f"samples/s (asked for {RATE_HZ})")
        except KeyboardInterrupt:
            display.log(f"\n[{PROGRAM}] stopped by Ctrl+C after {cycle} cycles - arm holds its current pose")
        except Exception as e:
            display.log(f"\n[{PROGRAM}] stopped: {e} - arm holds its current pose")
        finally:
            if rows:
                print_joint_summary(rows, load_limits)
                if SAVE_CSV:
                    print(f"[{PROGRAM}] joint log saved: {save_csv(rows)}")

        if finished:
            arm.move_to({JOINT: centre}, duration=0.5)
            if RETURN_TO_START:
                print(f"[{PROGRAM}] returning to the pose the arm started in")
                arm.move_to(initial, duration=MOVE_TIME_S)
        # The arm keeps holding its pose after the program exits (torque stays on).


if __name__ == "__main__":
    main()
