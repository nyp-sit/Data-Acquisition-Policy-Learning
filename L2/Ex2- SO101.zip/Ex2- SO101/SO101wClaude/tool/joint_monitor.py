"""joint_monitor.py - live joint table for the real SO-101 follower arm.

Real-arm counterpart of the Isaac Sim "SO101 Joint Monitor" window. It reads the STS3215 servos'
own feedback registers and shows, per joint: position, target, error, velocity, load, current,
temperature and where the joint sits inside its calibrated range.

Run from C:\\SO101wClaude:
    & $py tool\\joint_monitor.py               # live table, Ctrl+C to stop
    & $py tool\\joint_monitor.py --once        # one snapshot (like print_joints() in the sim)
    & $py tool\\joint_monitor.py --torque-off  # arm goes limp: move it by hand, watch the numbers

arm_forward_back.py imports read_joints / render_table / LiveDisplay from here, so it shows the
same table while it moves the arm. Only one program can open the serial port at a time.
"""

from __future__ import annotations

import argparse
import math
import os
import sys
import time

from so101_arm import DEFAULT_ID, DEFAULT_PORT, GRIPPER, JOINTS, SO101Arm

# STS3215 register units.
STEPS_PER_REV = 4096          # Present_Velocity is in steps/s
CURRENT_MA_PER_UNIT = 6.5     # Present_Current: ~6.5 mA per unit
LOAD_PERCENT_PER_UNIT = 0.1   # Present_Load / Torque_Limit: 0.1 % of maximum torque per unit

# Colour thresholds, same idea as the sim monitor.
ERR_WARN_DEG = 3.0            # error turns yellow above this (gripper: %)
SAT_FRACTION = 0.95           # load turns red / SAT at this fraction of Torque_Limit
LIMIT_WARN_FRACTION = 0.03    # limit bar turns red within 3 % of either end
TEMP_WARN_C = 50              # temperature turns yellow above this

RED, YELLOW, GREEN, DIM, BOLD, RESET = "\x1b[31m", "\x1b[33m", "\x1b[32m", "\x1b[2m", "\x1b[1m", "\x1b[0m"


def enable_ansi() -> None:
    """Turn on colour / cursor codes in the classic Windows console (no-op elsewhere)."""
    if os.name == "nt":
        os.system("")


def read_joints(arm: SO101Arm, with_temperature: bool = True) -> dict[str, dict[str, float]]:
    """One feedback sample per joint: pos (deg, gripper %), vel (deg/s), load (%), current (mA), temp (C)."""
    bus = arm.robot.bus
    pos = bus.sync_read("Present_Position", num_retry=2)
    vel = bus.sync_read("Present_Velocity", num_retry=2)
    load = bus.sync_read("Present_Load", num_retry=2)
    cur = bus.sync_read("Present_Current", num_retry=2)
    temp = bus.sync_read("Present_Temperature", num_retry=2) if with_temperature else {}
    return {
        j: {
            "pos": float(pos[j]),
            "vel": vel[j] * 360 / STEPS_PER_REV,
            "load": load[j] * LOAD_PERCENT_PER_UNIT,
            "current": cur[j] * CURRENT_MA_PER_UNIT,
            "temp": float(temp[j]) if j in temp else math.nan,
        }
        for j in JOINTS
    }


def read_load_limits(arm: SO101Arm) -> dict[str, float]:
    """Each servo's Torque_Limit in % of maximum torque (100 for arm joints, 50 for the gripper)."""
    limits = arm.robot.bus.sync_read("Torque_Limit", num_retry=2)
    return {j: limits[j] * LOAD_PERCENT_PER_UNIT for j in JOINTS}


def read_goals(arm: SO101Arm) -> dict[str, float]:
    """Where each servo is currently told to go (Goal_Position), deg / gripper %."""
    return {j: float(v) for j, v in arm.robot.bus.sync_read("Goal_Position", num_retry=2).items()}


def limit_bar(pos: float, lo: float, hi: float, width: int = 14) -> str:
    frac = (pos - lo) / (hi - lo) if hi > lo else 0.0
    filled = round(min(1.0, max(0.0, frac)) * width)
    bar = "#" * filled + "." * (width - filled)
    colour = RED if frac < LIMIT_WARN_FRACTION or frac > 1 - LIMIT_WARN_FRACTION else GREEN
    return f"{colour}[{bar}]{RESET}"


def render_table(
    sample: dict[str, dict[str, float]],
    targets: dict[str, float],
    limits: dict[str, tuple[float, float]],
    load_limits: dict[str, float],
    header: str = "",
    highlight: str | None = None,
) -> str:
    """The joint table as a string. Units: deg (gripper %), deg/s, % of max torque, mA, C."""
    lines = [f"{BOLD}{header}{RESET}"] if header else []
    lines.append(f"{'joint':<15}{'pos':>8}{'target':>8}{'error':>8}{'vel':>8}{'load %':>8}"
                 f"{'mA':>7}{'temp':>6}  limits (min .. max)")
    for j in JOINTS:
        s = sample[j]
        err = targets[j] - s["pos"]
        lo, hi = limits[j]
        sat = abs(s["load"]) >= SAT_FRACTION * load_limits[j]
        err_txt = f"{YELLOW}{err:+8.1f}{RESET}" if abs(err) > ERR_WARN_DEG else f"{err:+8.1f}"
        load_txt = f"{RED}{s['load']:+5.1f}SAT{RESET}" if sat else f"{s['load']:+8.1f}"
        temp_txt = "   -" if math.isnan(s["temp"]) else f"{s['temp']:4.0f}"
        if s["temp"] > TEMP_WARN_C:
            temp_txt = f"{YELLOW}{temp_txt}{RESET}"
        mark = ">" if j == highlight else " "
        unit = " %" if j == GRIPPER else ""
        lines.append(
            f"{mark}{j + unit:<14}{s['pos']:+8.1f}{targets[j]:+8.1f}{err_txt}{s['vel']:+8.1f}{load_txt}"
            f"{s['current']:7.0f}  {temp_txt}  {limit_bar(s['pos'], lo, hi)} {lo:+.0f} .. {hi:+.0f}"
        )
    return "\n".join(lines)


class LiveDisplay:
    """Redraws a block of text in place; log() prints a line above it without breaking it."""

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self.lines = 0
        self.text = ""
        if enabled:
            enable_ansi()

    def _clear(self) -> None:
        if self.lines:
            sys.stdout.write(f"\x1b[{self.lines}F\x1b[J")
            self.lines = 0

    def draw(self, text: str) -> None:
        if not self.enabled:
            return
        self._clear()
        sys.stdout.write(text + "\n")
        sys.stdout.flush()
        self.lines = text.count("\n") + 1
        self.text = text

    def log(self, line: str) -> None:
        self._clear()
        print(line, flush=True)
        if self.enabled and self.text:
            self.draw(self.text)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--port", default=DEFAULT_PORT)
    parser.add_argument("--id", default=DEFAULT_ID)
    parser.add_argument("--once", action="store_true", help="print one snapshot and exit")
    parser.add_argument("--torque-off", action="store_true",
                        help="disable torque so the arm can be moved by hand (support it first!)")
    parser.add_argument("--rate", type=float, default=5.0, help="refreshes per second")
    args = parser.parse_args()

    enable_ansi()
    with SO101Arm(port=args.port, robot_id=args.id) as arm:
        limits, load_limits = arm.joint_limits, read_load_limits(arm)
        if args.torque_off:
            arm.torque_off()
        state = "torque OFF - move the arm by hand" if args.torque_off else "torque ON - holding"
        if args.once:
            print(render_table(read_joints(arm), read_goals(arm), limits, load_limits, f"SO-101 ({state})"))
            return

        display = LiveDisplay()
        display.log("Joint monitor running. Ctrl+C to stop.")
        t0 = time.perf_counter()
        try:
            while True:
                sample = read_joints(arm)
                # With torque off the servo doesn't track its goal, so show error against itself.
                targets = {j: s["pos"] for j, s in sample.items()} if args.torque_off else read_goals(arm)
                header = f"SO-101 joint monitor  t={time.perf_counter() - t0:6.1f}s  ({state})"
                display.draw(render_table(sample, targets, limits, load_limits, header))
                time.sleep(1 / args.rate)
        except KeyboardInterrupt:
            pass
        finally:
            if args.torque_off:
                display.log("Torque is still OFF. Run 'tool\\so101_cli.py torque on' with the arm supported.")


if __name__ == "__main__":
    main()
